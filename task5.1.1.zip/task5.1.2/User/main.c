/*
 * 实验4 · task5.1.2：uC/OS-II 两个 LED 任务
 *
 * 本工程作为最终三任务工程 task5.1.3 的中间步骤：
 *   任务1：PA1 外接 LED，周期 1s（亮 500ms、灭 500ms）；
 *   任务2：PA2 外接 LED，周期 3s（亮 1500ms、灭 1500ms）。
 * 两个任务由 uC/OS-II 同时调度，不是依次执行。
 *
 * LED 为低电平点亮，接线必须是：
 *   3.3V -> 220~330ohm 电阻 -> LED 长脚(正极) -> LED 短脚(负极) -> PA1/PA2。
 * DAP-LINK 只占用 PA13(SWDIO)、PA14(SWCLK)，不会与 LED 冲突。
 */

#include "stm32f10x.h"
#include "os.h"
#include "cpu.h"
#include "Delay.h"
#include "LED.h"
#include "USART.h"

#define START_TASK_PRIO     5u
#define LED1_TASK_PRIO      6u
#define LED2_TASK_PRIO      7u
#define START_STK_SIZE      128u
#define LED_STK_SIZE        96u

static OS_STK StartTaskStk[START_STK_SIZE];
static OS_STK Led1TaskStk[LED_STK_SIZE];
static OS_STK Led2TaskStk[LED_STK_SIZE];

static void StartTask(void *pdata);
static void Led1Task(void *pdata);
static void Led2Task(void *pdata);

static void PrintBanner(void)
{
	USART1_SendString("\r\n");
	USART1_SendString("===============================================\r\n");
	USART1_SendString(" task5.1.2 - uC/OS-II two LED tasks\r\n");
	USART1_SendString(" Task1: PA1 LED, period 1s, priority 6\r\n");
	USART1_SendString(" Task2: PA2 LED, period 3s, priority 7\r\n");
	USART1_SendString(" UART : USART1 PA9(TX), 115200 8N1\r\n");
	USART1_SendString("===============================================\r\n");
}

int main(void)
{
	Delay_Init();
	USART1_Init(115200);
	LED_Init();
	PrintBanner();

	OSInit();
	OSTaskCreate(StartTask, (void *)0,
	             &StartTaskStk[START_STK_SIZE - 1u], START_TASK_PRIO);
	OSStart();

	while (1)
	{
	}
}

static void StartTask(void *pdata)
{
	(void)pdata;
	OSTaskCreate(Led1Task, (void *)0,
	             &Led1TaskStk[LED_STK_SIZE - 1u], LED1_TASK_PRIO);
	OSTaskCreate(Led2Task, (void *)0,
	             &Led2TaskStk[LED_STK_SIZE - 1u], LED2_TASK_PRIO);
	OS_CPU_SysTickInit(SystemCoreClock / OS_TICKS_PER_SEC);
	USART1_SendString("[OS] scheduler started, 2 LED tasks running\r\n");
	OSTaskSuspend(OS_PRIO_SELF);
}

static void Led1Task(void *pdata)
{
	(void)pdata;
	while (1)
	{
		LED1_ON();
		OSTimeDly(500);
		LED1_OFF();
		OSTimeDly(500);
	}
}

static void Led2Task(void *pdata)
{
	(void)pdata;
	while (1)
	{
		LED2_ON();
		OSTimeDly(1500);
		LED2_OFF();
		OSTimeDly(1500);
	}
}
