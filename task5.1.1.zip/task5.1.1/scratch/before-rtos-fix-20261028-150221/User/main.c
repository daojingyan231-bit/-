/*
 * 实验5 · 任务5.1.1
 * uC/OS-II 移植到 STM32F103C8T6，并创建 1 个 LED 任务（移植验证）
 *
 * 题目要求（实验4 任务一）：
 *   “学习嵌入式实时操作系统（RTOS），以 uC/OS 为例，将其移植到 STM32F103 上，
 *     构建至少 3 个任务：其中第 1、2 个 task 分别以 1s 和 3s 周期对 LED 等进行点亮-熄灭控制；
 *     第 3 个 task 以 2s 周期通过串口发送 hello uC/OS! 欢迎来到 RTOS 多任务环境！”
 *
 * 本工程完成其中的“移植 + 第 1 个 LED 任务”，用来先验证内核能跑起来：
 *   任务 1（优先级 6）：LED1（PA1）1s 周期闪烁 —— 亮 500ms、灭 500ms；
 *   启动任务（优先级 5）：创建 LED1 任务，启动 SysTick 节拍，然后挂起自己。
 * 第 2 个 LED 任务在 task5.1.2，第 3 个串口任务在 task5.1.3。
 *
 * 硬件：
 *   LED1  PA1 --- 220Ω --- LED --- GND   （低电平点亮）
 *   板载 PC13 与 LED1 同步翻转，没接外部 LED 时也能看到程序在跑
 *   串口 PA9(TX) -> USB 转串口 RXD，PA10(RX) -> TXD，GND 共地，115200 8N1
 *
 * 内核：uC/OS-II V2.93.01（源码在 Middlewares/uC-OS2，Apache-2.0）
 * 节拍：SysTick 1ms 一次，OS_TICKS_PER_SEC = 1000
 */

#include "stm32f10x.h"
#include "os.h"
#include "cpu.h"
#include "Delay.h"
#include "LED.h"
#include "USART.h"

/* ---------------- 任务优先级与栈大小 ---------------- */
#define START_TASK_PRIO     5u
#define LED1_TASK_PRIO      6u

#define START_STK_SIZE      128u
#define LED_STK_SIZE        96u

static OS_STK StartTaskStk[START_STK_SIZE];
static OS_STK Led1TaskStk[LED_STK_SIZE];

static void StartTask(void *pdata);
static void Led1Task(void *pdata);

/* ---------------- 板载 PC13 指示灯（低电平点亮） ---------------- */
static void BoardLed_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);              /* 先熄灭 */
}

static void BoardLed_On(void)  { GPIO_ResetBits(GPIOC, GPIO_Pin_13); }
static void BoardLed_Off(void) { GPIO_SetBits(GPIOC, GPIO_Pin_13); }

/* ---------------- 串口横幅 ---------------- */
static void PrintBanner(void)
{
	USART1_SendString("\r\n");
	USART1_SendString("==================================================\r\n");
	USART1_SendString(" Experiment 5 - Task 5.1.1\r\n");
	USART1_SendString(" uC/OS-II port + LED1 task (1s)\r\n");
	USART1_SendString(" MCU : STM32F103C8T6 @72MHz\r\n");
	USART1_SendString(" OS  : uC/OS-II V2.93.01, SysTick 1ms\r\n");
	USART1_SendString(" LED1: PA1, 1s period (500ms on / 500ms off), prio 6\r\n");
	USART1_SendString(" UART: USART1 PA9(TX) 115200 8N1\r\n");
	USART1_SendString("==================================================\r\n");
}

int main(void)
{
	Delay_Init();                    /* DWT 延时，给 SysTick 让路 */
	USART1_Init(115200);
	LED_Init();
	BoardLed_Init();

	PrintBanner();

	OSInit();                        /* 初始化 uC/OS-II：TCB、就绪表、空闲任务 */
	OSTaskCreate(StartTask,          /* 启动任务 */
	             (void *)0,
	             &StartTaskStk[START_STK_SIZE - 1u],
	             START_TASK_PRIO);

	OSStart();                       /* 启动调度器，从此不再返回 */

	while (1)
	{
	}
}

/**
  * @brief  启动任务：创建应用任务，启动系统节拍，然后挂起自己
  */
static void StartTask(void *pdata)
{
	(void)pdata;

	OSTaskCreate(Led1Task, (void *)0, &Led1TaskStk[LED_STK_SIZE - 1u], LED1_TASK_PRIO);

	/* SysTick 作为 uC/OS-II 的系统节拍：72MHz / 1000Hz = 72000 个周期中断一次 */
	OS_CPU_SysTickInit(SystemCoreClock / OS_TICKS_PER_SEC);

	USART1_SendString("[OS] scheduler started, LED1 task is running\r\n");

	OSTaskSuspend(OS_PRIO_SELF);     /* 启动任务用完就挂起，不再占用 CPU */
}

/**
  * @brief  任务 1：LED1 以 1s 为周期闪烁
  * @note   1s 周期 = 亮 0.5s + 灭 0.5s；OSTimeDly(500) = 500 个 1ms 节拍
  */
static void Led1Task(void *pdata)
{
	(void)pdata;

	while (1)
	{
		LED1_ON();
		BoardLed_On();
		OSTimeDly(500);

		LED1_OFF();
		BoardLed_Off();
		OSTimeDly(500);
	}
}
