#ifndef __USART_H
#define __USART_H

#include "stm32f10x.h"

/*
 * USART1：PA9 = TX，PA10 = RX，115200 8N1
 * 用途：把任务运行信息、温湿度数据从串口送到上位机（Win10 串口助手）。
 *
 * 接线：PA9(TX) -> USB 转串口模块 RXD，PA10(RX) -> 模块 TXD，GND 共地。
 */

void USART1_Init(uint32_t BaudRate);
void USART1_SendByte(uint8_t Byte);
void USART1_SendString(const char *String);
void USART1_SendInt(int32_t Value);         /* 发送有符号整数 */
void USART1_SendUnsigned(uint32_t Value);   /* 发送无符号整数 */
void USART1_SendDec1(int32_t Value10);      /* 发送 1 位小数，253 -> "25.3" */
void USART1_SendNewLine(void);              /* 发送 "\r\n" */

#endif
