#include "stm32f10x.h"
#include "Delay.h"

#ifdef USE_UCOS_II
#include "os.h"
#endif

/*
 * DWT（Data Watchpoint and Trace）里有一个 32 位的自由运行周期计数器 CYCCNT，
 * 每来一个 CPU 时钟周期加 1。72MHz 下计满 2^32 约需 59.6 秒，
 * 这里只做微秒/毫秒级短延时，用“当前值 - 起始值”的无符号减法即可，
 * 计数器回绕也不会算错。
 *
 * 说明：SPL 自带的 core_cm3.h 版本较老，没有定义 DWT 结构体，
 *       所以这里直接按 Cortex-M3 的寄存器地址访问（地址来自 ARM 官方手册）。
 */
#define DWT_CTRL_ADDR       (*(volatile uint32_t *)0xE0001000u)
#define DWT_CYCCNT_ADDR     (*(volatile uint32_t *)0xE0001004u)
#define DEMCR_ADDR          (*(volatile uint32_t *)0xE000EDFCu)

#define DWT_CTRL_CYCCNTENA  (1u << 0)
#define DEMCR_TRCENA        (1u << 24)

static uint8_t Delay_DWT_Ready = 0;

static void Delay_DWT_Init(void)
{
	DEMCR_ADDR |= DEMCR_TRCENA;              /* 打开跟踪单元的电源/时钟 */
	DWT_CYCCNT_ADDR = 0;
	DWT_CTRL_ADDR |= DWT_CTRL_CYCCNTENA;     /* 启动周期计数器 */
	Delay_DWT_Ready = 1;
}

void Delay_Init(void)
{
	if (Delay_DWT_Ready == 0)
	{
		Delay_DWT_Init();
	}
}

static void Delay_Cycles(uint32_t Cycles)
{
	uint32_t Start;

	if (Delay_DWT_Ready == 0)
	{
		Delay_DWT_Init();
	}

	Start = DWT_CYCCNT_ADDR;
	while ((DWT_CYCCNT_ADDR - Start) < Cycles)
	{
		__NOP();
	}
}

void Delay_us(uint32_t us)
{
	/* SystemCoreClock 在 system_stm32f10x.c 里被设为 72000000 */
	Delay_Cycles(us * (SystemCoreClock / 1000000u));
}

void Delay_ms(uint32_t ms)
{
#ifdef USE_UCOS_II
	/*
	 * RTOS 下不要死等：OSTimeDly() 会把当前任务挂起 ms 个节拍，
	 * CPU 去跑 LED 等其它任务，时间到了再回来。
	 * 注意 OS_TICKS_PER_SEC = 1000，所以 1 个节拍正好 1ms。
	 */
	if (OSRunning == OS_TRUE)
	{
		while (ms > 0u)
		{
			INT16U Chunk = (ms > 1000u) ? (INT16U)1000u : (INT16U)ms;
			OSTimeDly(Chunk);
			ms -= Chunk;
		}
		return;
	}
#endif

	while (ms--)
	{
		Delay_us(1000);
	}
}

void Delay_s(uint32_t s)
{
	while (s--)
	{
		Delay_ms(1000);
	}
}
