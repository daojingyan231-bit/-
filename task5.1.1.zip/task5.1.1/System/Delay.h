#ifndef __DELAY_H
#define __DELAY_H

#include "stm32f10x.h"

/*
 * 延时函数（DWT 内核周期计数器版本）
 *
 * 为什么不用 SysTick？
 *   裸机程序常用 SysTick 做 Delay，但 uC/OS-II 要拿 SysTick 当系统节拍（1ms 一次中断），
 *   两边同时改 SysTick 会互相打架。所以这里改用 Cortex-M3 内核自带的 DWT->CYCCNT
 *   周期计数器：只读计数器、不占中断，裸机和 RTOS 下都能用。
 *
 * 在 RTOS 工程里（工程宏 USE_UCOS_II），Delay_ms() 会自动改用 OSTimeDly()，
 * 让出 CPU 给其它任务，而不是死等。
 */

void Delay_Init(void);              /* 使能 DWT 周期计数器（可省略，首次调用会自动初始化） */
void Delay_us(uint32_t us);
void Delay_ms(uint32_t ms);
void Delay_s(uint32_t s);

#endif
