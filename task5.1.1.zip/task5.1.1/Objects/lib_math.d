.\objects\lib_math.o: Middlewares\uC-OS2\uC-LIB\lib_math.c
.\objects\lib_math.o: .\Middlewares\uC-OS2\uC-LIB\lib_math.h
.\objects\lib_math.o: .\Middlewares\uC-OS2\uC-CPU\ARM-Cortex-M\ARMv7-M\ARM\cpu.h
.\objects\lib_math.o: .\Middlewares\uC-OS2\uC-CPU\cpu_def.h
.\objects\lib_math.o: .\Middlewares\uC-OS2\uC-CPU\Cfg\cpu_cfg.h
.\objects\lib_math.o: .\Middlewares\uC-OS2\uC-CPU\cpu_core.h
.\objects\lib_math.o: .\Middlewares\uC-OS2\uC-LIB\lib_def.h
