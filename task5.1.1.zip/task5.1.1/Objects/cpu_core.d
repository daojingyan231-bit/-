.\objects\cpu_core.o: Middlewares\uC-OS2\uC-CPU\cpu_core.c
.\objects\cpu_core.o: Middlewares\uC-OS2\uC-CPU\cpu_core.h
.\objects\cpu_core.o: .\Middlewares\uC-OS2\uC-CPU\ARM-Cortex-M\ARMv7-M\ARM\cpu.h
.\objects\cpu_core.o: .\Middlewares\uC-OS2\uC-CPU\cpu_def.h
.\objects\cpu_core.o: .\Middlewares\uC-OS2\uC-CPU\Cfg\cpu_cfg.h
.\objects\cpu_core.o: .\Middlewares\uC-OS2\uC-LIB\lib_def.h
