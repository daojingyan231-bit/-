/*
*********************************************************************************************************
*                                              uC/OS-II
*                                        The Real-Time Kernel
*
*                    Copyright 1992-2021 Silicon Laboratories Inc. www.silabs.com
*
*                                 SPDX-License-Identifier: APACHE-2.0
*
*               This software is subject to an open source license and is distributed by
*                Silicon Laboratories Inc. pursuant to the terms of the Apache License,
*                    Version 2.0 available at www.apache.org/licenses/LICENSE-2.0.
*
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                 uC/OS-II Configuration File for V2.9x
*
* Filename : os_cfg.h
* Version  : V2.93.01
*
* 说明：本文件按 STM32F103C8T6（64KB Flash / 20KB RAM）做了裁剪，
*       只保留任务调度、延时、挂起/恢复这些本次实验用到的功能。
*********************************************************************************************************
*/

#ifndef OS_CFG_H
#define OS_CFG_H


                                       /* ---------------------- MISCELLANEOUS ----------------------- */
#define OS_APP_HOOKS_EN           1u   /* 应用层钩子（app_hooks.c）                                    */
#define OS_ARG_CHK_EN             1u   /* 参数检查                                                     */
#define OS_CPU_HOOKS_EN           1u   /* 移植层钩子（os_cpu_c.c）                                     */

#define OS_DEBUG_EN               1u   /* 调试变量                                                     */

#define OS_EVENT_MULTI_EN         0u   /* 不用“同时等待多个事件”                                       */
#define OS_EVENT_NAME_EN          0u   /* 不给信号量/邮箱起名字                                        */

#define OS_LOWEST_PRIO            9u   /* 优先级 0~9，数字越大优先级越低                               */
                                       /* 空闲任务固定用 OS_LOWEST_PRIO                                */
#define OS_MAX_EVENTS             4u   /* 事件控制块数量                                               */
#define OS_MAX_FLAGS              2u   /* 事件标志组数量                                               */
#define OS_MAX_MEM_PART           2u   /* 内存分区数量                                                 */
#define OS_MAX_QS                 2u   /* 消息队列数量                                                 */
#define OS_MAX_TASKS              6u   /* 最多 6 个任务（含空闲任务）                                  */

#define OS_SCHED_LOCK_EN          0u   /* 不用 OSSchedLock()                                           */

#define OS_TICK_STEP_EN           0u   /* 不用 uC/OS-View 的单步节拍                                   */
#define OS_TICKS_PER_SEC       1000u   /* 1ms 一个节拍                                                 */

#define OS_TLS_TBL_SIZE           0u   /* 不用线程局部存储                                             */


                                       /* --------------------- TASK STACK SIZE ---------------------- */
#define OS_TASK_TMR_STK_SIZE     64u   /* 定时器任务（本工程未启用）                                   */
#define OS_TASK_STAT_STK_SIZE    64u   /* 统计任务（本工程未启用）                                     */
#define OS_TASK_IDLE_STK_SIZE    64u   /* 空闲任务栈：64 个字 = 256 字节                               */


                                       /* --------------------- TASK MANAGEMENT ---------------------- */
#define OS_TASK_CHANGE_PRIO_EN    0u   /* 不改变任务优先级                                             */
#define OS_TASK_CREATE_EN         1u   /* OSTaskCreate()                                               */
#define OS_TASK_CREATE_EXT_EN     0u   /* 不用 OSTaskCreateExt()                                       */
#define OS_TASK_DEL_EN            0u   /* 不删除任务                                                   */
#define OS_TASK_NAME_EN           0u   /* 任务名                                                       */
#define OS_TASK_PROFILE_EN        0u   /* 任务运行统计                                                 */
#define OS_TASK_QUERY_EN          0u   /* 不查询任务信息                                               */
#define OS_TASK_REG_TBL_SIZE      1u   /* 任务变量表                                                   */
#define OS_TASK_STAT_EN           0u   /* 不开统计任务，省 RAM                                         */
#define OS_TASK_STAT_STK_CHK_EN   0u   /* 不做栈检查                                                   */
#define OS_TASK_SUSPEND_EN        1u   /* 启动任务创建完其它任务后挂起自己                             */
#define OS_TASK_SW_HOOK_EN        1u   /* 任务切换钩子                                                 */


                                       /* ----------------------- EVENT FLAGS ------------------------ */
#define OS_FLAG_EN                0u
#define OS_FLAG_ACCEPT_EN         0u
#define OS_FLAG_DEL_EN            0u
#define OS_FLAG_NAME_EN           0u
#define OS_FLAG_QUERY_EN          0u
#define OS_FLAG_WAIT_CLR_EN       0u
#define OS_FLAGS_NBITS           16u


                                       /* -------------------- MESSAGE MAILBOXES --------------------- */
#define OS_MBOX_EN                0u
#define OS_MBOX_ACCEPT_EN         0u
#define OS_MBOX_DEL_EN            0u
#define OS_MBOX_PEND_ABORT_EN     0u
#define OS_MBOX_POST_EN           0u
#define OS_MBOX_POST_OPT_EN       0u
#define OS_MBOX_QUERY_EN          0u


                                       /* --------------------- MEMORY MANAGEMENT -------------------- */
#define OS_MEM_EN                 0u
#define OS_MEM_NAME_EN            0u
#define OS_MEM_QUERY_EN           0u


                                       /* ---------------- MUTUAL EXCLUSION SEMAPHORES --------------- */
#define OS_MUTEX_EN               0u
#define OS_MUTEX_ACCEPT_EN        0u
#define OS_MUTEX_DEL_EN           0u
#define OS_MUTEX_QUERY_EN         0u


                                       /* ---------------------- MESSAGE QUEUES ---------------------- */
#define OS_Q_EN                   0u
#define OS_Q_ACCEPT_EN            0u
#define OS_Q_DEL_EN               0u
#define OS_Q_FLUSH_EN             0u
#define OS_Q_PEND_ABORT_EN        0u
#define OS_Q_POST_EN              0u
#define OS_Q_POST_FRONT_EN        0u
#define OS_Q_POST_OPT_EN          0u
#define OS_Q_QUERY_EN             0u


                                       /* ------------------------ SEMAPHORES ------------------------ */
#define OS_SEM_EN                 0u
#define OS_SEM_ACCEPT_EN          0u
#define OS_SEM_DEL_EN             0u
#define OS_SEM_PEND_ABORT_EN      0u
#define OS_SEM_QUERY_EN           0u
#define OS_SEM_SET_EN             0u


                                       /* --------------------- TIME MANAGEMENT ---------------------- */
#define OS_TIME_DLY_HMSM_EN       0u   /* 不用 OSTimeDlyHMSM()                                         */
#define OS_TIME_DLY_RESUME_EN     0u
#define OS_TIME_GET_SET_EN        0u
#define OS_TIME_TICK_HOOK_EN      0u


                                       /* --------------------- TIMER MANAGEMENT --------------------- */
#define OS_TMR_EN                 0u   /* 不用软件定时器                                               */
#define OS_TMR_CFG_MAX           16u
#define OS_TMR_CFG_NAME_EN        0u
#define OS_TMR_CFG_WHEEL_SIZE     7u
#define OS_TMR_CFG_TICKS_PER_SEC 100u


                                       /* ---------------------- TRACE RECORDER ---------------------- */
#define OS_TRACE_EN               0u
#define OS_TRACE_API_ENTER_EN     0u
#define OS_TRACE_API_EXIT_EN      0u

#endif
