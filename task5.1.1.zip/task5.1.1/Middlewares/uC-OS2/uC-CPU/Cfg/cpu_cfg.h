/*
*********************************************************************************************************
*                                               uC/CPU
*                                    CPU CONFIGURATION & PORT LAYER
*
*                    Copyright 2004-2021 Silicon Laboratories Inc. www.silabs.com
*
*                                 SPDX-License-Identifier: APACHE-2.0
*
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                       CPU CONFIGURATION FILE
*
* Filename : cpu_cfg.h
* Version  : V1.32.01
*
* 说明：STM32F103C8T6 是 Cortex-M3，无 FPU、无 Cache；
*       这里关掉时间戳和 CPU 名字，只保留中断临界区、优先级位数和前导零指令。
*********************************************************************************************************
*/

#ifndef  CPU_CFG_MODULE_PRESENT
#define  CPU_CFG_MODULE_PRESENT


#define  CPU_CFG_NAME_EN                        DEF_DISABLED
#define  CPU_CFG_NAME_SIZE                      16

#define  CPU_CFG_TS_32_EN                       DEF_DISABLED
#define  CPU_CFG_TS_64_EN                       DEF_DISABLED
#define  CPU_CFG_TS_TMR_SIZE                    CPU_WORD_SIZE_32

#if 0
#define  CPU_CFG_INT_DIS_MEAS_EN
#endif
#define  CPU_CFG_INT_DIS_MEAS_OVRHD_NBR         1u

#if 1
#define  CPU_CFG_LEAD_ZEROS_ASM_PRESENT
#endif

#if 1
#define  CPU_CFG_TRAIL_ZEROS_ASM_PRESENT
#endif

#if 1
#define  CPU_CFG_ENDIAN_TYPE             CPU_ENDIAN_TYPE_LITTLE
#endif

#define  CPU_CFG_CACHE_MGMT_EN                  DEF_DISABLED

/* 内核感知中断的优先级边界：优先级数值 >= 1 的中断里可以调用 uC/OS-II API */
#define  CPU_CFG_KA_IPL_BOUNDARY                1u

/* STM32 只有优先级寄存器的高 4 位可编程 */
#define  CPU_CFG_NVIC_PRIO_BITS                 4u


#endif                                                          /* End of CPU cfg module include.       */
