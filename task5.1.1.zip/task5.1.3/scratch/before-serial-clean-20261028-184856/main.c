/*
 * 实验4 · 任务一最终工程：uC/OS-II 三任务并发运行
 *
 *   任务1（优先级6）：PA1 LED，1s 周期（亮/灭各 500ms）；
 *   任务2（优先级7）：PA2 LED，3s 周期（亮/灭各 1500ms）；
 *   任务3（优先级8）：每 2s 由 USART1 发送：
 *                       hello uC/OS! 欢迎来到RTOS多任务环境！
 *
 * LED 采用低电平吸收电流方式：
 *   3.3V -> 220~330ohm -> LED 长脚(+) -> LED 短脚(-) -> PA1/PA2。
 * USART1：PA9(TX) -> DAP-LINK 串口 RX，PA10(RX) -> DAP-LINK 串口 TX，GND 共地。
 * 若所用 DAP-LINK 没有虚拟串口功能，仍需 USB-TTL 才能查看 USART1 输出。
 * DAP-LINK 的 SWD 下载线为 PA13/PA14，不会占用上述引脚。
 * 中文按 GBK 字节发送；Windows 串口助手请选择 GBK/ANSI，115200、8-N-1。
 */

#include "stm32f10x.h"
#include "os.h"
#include "cpu.h"
#include "Delay.h"
#include "LED.h"
#include "USART.h"

#define START_TASK_PRIO     5u
#define LED1_TASK_PRIO      6u
#define LED2_TASK_PRIO      7u
#define UART_TASK_PRIO      8u
#define START_STK_SIZE      128u
#define LED_STK_SIZE        96u
#define UART_STK_SIZE       160u

static OS_STK StartTaskStk[START_STK_SIZE];
static OS_STK Led1TaskStk[LED_STK_SIZE];
static OS_STK Led2TaskStk[LED_STK_SIZE];
static OS_STK UartTaskStk[UART_STK_SIZE];

static void StartTask(void *pdata);
static void Led1Task(void *pdata);
static void Led2Task(void *pdata);
static void UartTask(void *pdata);

static void BoardLed_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);
}

static void BoardLed_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13) == 0)
	{
		GPIO_SetBits(GPIOC, GPIO_Pin_13);
	}
	else
	{
		GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	}
}

/* GBK：欢迎来到 + ASCII RTOS + 多任务环境！ */
static const char MsgHello[] =
	"hello uC/OS! "
	"\xBB\xB6\xD3\xAD\xC0\xB4\xB5\xBD"
	"RTOS"
	"\xB6\xE0\xC8\xCE\xCE\xF1\xBB\xB7\xBE\xB3\xA3\xA1"
	"\r\n";

static void PrintBanner(void)
{
	USART1_SendString("\r\n");
	USART1_SendString("==================================================\r\n");
	USART1_SendString(" task5.1.3 - uC/OS-II final three-task system\r\n");
	USART1_SendString(" Task1: PA1 LED, period 1s, priority 6\r\n");
	USART1_SendString(" Task2: PA2 LED, period 3s, priority 7\r\n");
	USART1_SendString(" Task3: USART1 message, period 2s, priority 8\r\n");
	USART1_SendString(" UART : PA9/PA10, 115200 8N1, Chinese=GBK\r\n");
	USART1_SendString("==================================================\r\n");
}

int main(void)
{
	Delay_Init();
	USART1_Init(115200);
	LED_Init();
	BoardLed_Init();
	PrintBanner();

	OSInit();
	OSTaskCreate(StartTask, (void *)0,
	             &StartTaskStk[START_STK_SIZE - 1u], START_TASK_PRIO);
	OSStart();

	while (1)
	{
	}
}

static void StartTask(void *pdata)
{
	(void)pdata;
	OSTaskCreate(Led1Task, (void *)0,
	             &Led1TaskStk[LED_STK_SIZE - 1u], LED1_TASK_PRIO);
	OSTaskCreate(Led2Task, (void *)0,
	             &Led2TaskStk[LED_STK_SIZE - 1u], LED2_TASK_PRIO);
	OSTaskCreate(UartTask, (void *)0,
	             &UartTaskStk[UART_STK_SIZE - 1u], UART_TASK_PRIO);
	OS_CPU_SysTickInit(SystemCoreClock / OS_TICKS_PER_SEC);
	USART1_SendString("[OS] scheduler started, 3 tasks running\r\n");
	OSTaskSuspend(OS_PRIO_SELF);
}

static void Led1Task(void *pdata)
{
	(void)pdata;
	while (1)
	{
		LED1_ON();
		OSTimeDly(500);
		LED1_OFF();
		OSTimeDly(500);
	}
}

static void Led2Task(void *pdata)
{
	(void)pdata;
	while (1)
	{
		LED2_ON();
		OSTimeDly(1500);
		LED2_OFF();
		OSTimeDly(1500);
	}
}

static void UartTask(void *pdata)
{
	(void)pdata;
	while (1)
	{
		USART1_SendString(MsgHello);
		BoardLed_Turn();
		OSTimeDly(2000);
	}
}
