/*
 * 实验5 · 任务5.1.3
 * uC/OS-II 移植到 STM32F103C8T6，只保留第 3 个任务：串口每 2s 发 hello
 *
 * 题目要求（实验4 任务一）：
 *   “学习嵌入式实时操作系统（RTOS），以 uC/OS 为例，将其移植到 STM32F103 上，
 *     构建至少 3 个任务：其中第 1、2 个 task 分别以 1s 和 3s 周期对 LED 等进行点亮-熄灭控制；
 *     第 3 个 task 以 2s 周期通过串口发送 hello uC/OS! 欢迎来到 RTOS 多任务环境！”
 *
 * 按“每个工程只保留一个任务”拆分：
 *   task5.1.1：只有第 1 个任务 LED1（PA1，1s）
 *   task5.1.2：只有第 2 个任务 LED2（PA2，3s）
 *   task5.1.3：本工程，只有第 3 个任务：每 2s 通过 USART1 发送
 *              “hello uc/OS! 欢迎来到RTOS多任务环境！”
 * 三个工程都包含完整的 uC/OS-II 移植（OSInit / OSTaskCreate / OSStart / SysTick 节拍）。
 *
 * 本工程的任务：
 *   启动任务（优先级 5）：创建串口任务，启动 SysTick 节拍，然后挂起自己；
 *   串口任务（优先级 8）：每 2s 发一行 hello；板载 PC13 每发一次翻转一次。
 *
 * 硬件：
 *   串口 PA9(TX) -> USB 转串口 RXD，PA10(RX) -> TXD，GND 共地，115200 8N1
 *   板载 PC13 做“任务在跑”指示，不用另接 LED
 *
 * 内核：uC/OS-II V2.93.01（源码在 Middlewares/uC-OS2，Apache-2.0）
 * 节拍：SysTick 1ms 一次，OS_TICKS_PER_SEC = 1000
 *
 * 串口中文说明：
 *   Windows 下常用的串口助手（SSCOM、XCOM）默认按 GBK 显示中文，
 *   所以中文用 GBK 字节发送（源码里写成 \xHH，避免 Keil 对 UTF-8 字符串报
 *   “invalid multibyte character sequence”）。串口助手编码请选 GBK/ANSI。
 */

#include "stm32f10x.h"
#include "os.h"
#include "cpu.h"
#include "Delay.h"
#include "USART.h"

/* ---------------- 任务优先级与栈大小 ---------------- */
#define START_TASK_PRIO     5u
#define UART_TASK_PRIO      8u

#define START_STK_SIZE      128u
#define UART_STK_SIZE       128u

static OS_STK StartTaskStk[START_STK_SIZE];
static OS_STK UartTaskStk[UART_STK_SIZE];

static void StartTask(void *pdata);
static void UartTask(void *pdata);

/* ---------------- 板载 PC13 指示灯（低电平点亮） ---------------- */
static void BoardLed_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);              /* 先熄灭 */
}

static void BoardLed_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13) == 0)
	{
		GPIO_SetBits(GPIOC, GPIO_Pin_13);
	}
	else
	{
		GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	}
}

/* ---------------- 串口横幅（ASCII） ---------------- */
static void PrintBanner(void)
{
	USART1_SendString("\r\n");
	USART1_SendString("==================================================\r\n");
	USART1_SendString(" Experiment 5 - Task 5.1.3\r\n");
	USART1_SendString(" uC/OS-II port + UART task (hello every 2s)\r\n");
	USART1_SendString(" MCU : STM32F103C8T6 @72MHz\r\n");
	USART1_SendString(" OS  : uC/OS-II V2.93.01, SysTick 1ms\r\n");
	USART1_SendString(" UART: PA9(TX) 115200 8N1, Chinese in GBK\r\n");
	USART1_SendString(" PC13: toggles on every send\r\n");
	USART1_SendString("==================================================\r\n");
}

/*
 * “hello uc/OS! 欢迎来到RTOS多任务环境！”
 * 中文部分按 GBK 编码：BB B6 = 欢, D3 AD = 迎, C0 B4 = 来, B5 BD = 到,
 * B6 E0 = 多, C8 CE = 任, CE F1 = 务, BB B7 = 环, BE B3 = 境, A3 A1 = ！
 */
static const char MsgHello[] =
	"hello uc/OS! "
	"\xBB\xB6\xD3\xAD\xC0\xB4\xB5\xBD"      /* 欢迎来到 */
	"RTOS"
	"\xB6\xE0\xC8\xCE\xCE\xF1\xBB\xB7\xBE\xB3\xA3\xA1"  /* 多任务环境！ */
	"\r\n";

int main(void)
{
	Delay_Init();                    /* DWT 延时，给 SysTick 让路 */
	USART1_Init(115200);
	BoardLed_Init();

	PrintBanner();

	OSInit();                        /* 初始化 uC/OS-II：TCB、就绪表、空闲任务 */
	OSTaskCreate(StartTask,          /* 启动任务 */
	             (void *)0,
	             &StartTaskStk[START_STK_SIZE - 1u],
	             START_TASK_PRIO);

	OSStart();                       /* 启动调度器，从此不再返回 */

	while (1)
	{
	}
}

/**
  * @brief  启动任务：创建串口任务，启动系统节拍，然后挂起自己
  */
static void StartTask(void *pdata)
{
	(void)pdata;

	OSTaskCreate(UartTask, (void *)0, &UartTaskStk[UART_STK_SIZE - 1u], UART_TASK_PRIO);

	/* SysTick 作为 uC/OS-II 的系统节拍：72MHz / 1000Hz = 72000 个周期中断一次 */
	OS_CPU_SysTickInit(SystemCoreClock / OS_TICKS_PER_SEC);

	USART1_SendString("[OS] scheduler started, UART task is running\r\n");

	OSTaskSuspend(OS_PRIO_SELF);     /* 启动任务用完就挂起，不再占用 CPU */
}

/**
  * @brief  任务 3：每 2s 通过串口发送一行 hello
  */
static void UartTask(void *pdata)
{
	(void)pdata;

	while (1)
	{
		USART1_SendString(MsgHello);
		BoardLed_Turn();             /* 每发一次翻转 PC13，做运行指示 */
		OSTimeDly(2000);
	}
}
