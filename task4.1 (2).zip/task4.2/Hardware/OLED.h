#ifndef __OLED_H
#define __OLED_H

#include "stm32f10x.h"

/*
 * 任务2 专用 OLED 驱动：同一套显示代码，可以跑在两种接口上
 *
 *   OLED_USE_SPI = 0 ：软件 I2C —— SCL=PB6，SDA=PB7
 *   OLED_USE_SPI = 1 ：硬件 SPI1 —— SCK=PA5，MOSI=PA7，CS=PA4，DC=PA6，RES=PA3
 *
 * 改这一处宏，重新编译，就能用示波器/逻辑分析仪分别量 I2C 和 SPI 的波形，
 * 从而对照代码分析两种总线的时序差别（见 说明.md）。
 */
#define OLED_USE_SPI    0

#define OLED_ADDR       0x78        /* 默认 I2C 地址；程序也会自动尝试 0x7A */

extern uint8_t OLED_Addr;           /* 实际探测到的 8 位地址：0x78 或 0x7A */
extern uint8_t OLED_Detected;       /* 1=收到 OLED 应答，0=未收到 */

extern uint8_t OLED_GRAM[8][128];

void OLED_Init(void);
void OLED_Clear(void);
void OLED_Refresh(void);                            /* 整屏刷新（一次性突发写） */

void OLED_SetPixel(int16_t X, int16_t Y, uint8_t Color);
void OLED_DrawChar(int16_t X, int16_t Y, char Char);
void OLED_DrawString(int16_t X, int16_t Y, const char *String);
void OLED_DrawNum(int16_t X, int16_t Y, uint32_t Number, uint8_t Length);
void OLED_DrawDecimal1(int16_t X, int16_t Y, int32_t Value10);   /* 显示 1 位小数，如 25.3 */

#endif
