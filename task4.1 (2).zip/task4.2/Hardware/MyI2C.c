#include "stm32f10x.h"
#include "Delay.h"
#include "MyI2C.h"

/* ---------------- I2C1 默认引脚：PB6 = SCL，PB7 = SDA ---------------- */
#define MYI2C_W_SCL(x)      GPIO_WriteBit(GPIOB, GPIO_Pin_6, (BitAction)(x))
#define MYI2C_W_SDA(x)      GPIO_WriteBit(GPIOB, GPIO_Pin_7, (BitAction)(x))
#define MYI2C_R_SDA()       GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7)

/*
 * 每个半周期至少等待 4us，软件 I2C 约为 100kHz。
 * 速度低于 SSD1306/AHT20 的上限，在面包板和普通杜邦线上更可靠。
 */
static void MyI2C_Delay(void)
{
	Delay_us(4);
}

void MyI2C_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;      /* 开漏输出：既能输出也能读回 */
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	MYI2C_W_SCL(1);                                       /* 总线空闲：两根线都是高电平 */
	MYI2C_W_SDA(1);
}

uint8_t MyI2C_Probe(uint8_t Addr)
{
	uint8_t Ack;

	MyI2C_Start();
	MyI2C_SendByte(Addr);
	Ack = MyI2C_ReceiveAck();
	MyI2C_Stop();
	return Ack;
}

void MyI2C_Start(void)
{
	MYI2C_W_SDA(1);
	MYI2C_W_SCL(1);
	MyI2C_Delay();
	MYI2C_W_SDA(0);                                       /* SCL 高电平期间 SDA 下降 = 起始位 */
	MyI2C_Delay();
	MYI2C_W_SCL(0);
}

void MyI2C_Stop(void)
{
	MYI2C_W_SDA(0);
	MyI2C_Delay();
	MYI2C_W_SCL(1);
	MyI2C_Delay();
	MYI2C_W_SDA(1);                                       /* SCL 高电平期间 SDA 上升 = 停止位 */
	MyI2C_Delay();
}

void MyI2C_SendByte(uint8_t Byte)
{
	uint8_t i;
	for (i = 0; i < 8; i++)
	{
		MYI2C_W_SDA(Byte & (0x80 >> i));                  /* 高位先行 */
		MyI2C_Delay();
		MYI2C_W_SCL(1);
		MyI2C_Delay();
		MYI2C_W_SCL(0);
	}
}

uint8_t MyI2C_ReceiveByte(void)
{
	uint8_t i, Byte = 0x00;
	MYI2C_W_SDA(1);                                       /* 释放 SDA，交给从机驱动 */
	for (i = 0; i < 8; i++)
	{
		MYI2C_W_SCL(1);
		MyI2C_Delay();
		if (MYI2C_R_SDA())
		{
			Byte |= (0x80 >> i);
		}
		MYI2C_W_SCL(0);
		MyI2C_Delay();
	}
	return Byte;
}

void MyI2C_SendAck(uint8_t AckBit)
{
	MYI2C_W_SDA(AckBit);                                  /* 第 9 个时钟：0 应答，1 非应答 */
	MyI2C_Delay();
	MYI2C_W_SCL(1);
	MyI2C_Delay();
	MYI2C_W_SCL(0);
	MYI2C_W_SDA(1);
}

uint8_t MyI2C_ReceiveAck(void)
{
	uint8_t AckBit;
	MYI2C_W_SDA(1);                                       /* 释放 SDA，让从机拉低表示应答 */
	MyI2C_Delay();
	MYI2C_W_SCL(1);
	MyI2C_Delay();
	AckBit = MYI2C_R_SDA();
	MYI2C_W_SCL(0);
	return AckBit;
}

/**
  * @brief  连续写多个字节（一个起始位 + 地址 + Len 个数据 + 停止位）
  * @param  Addr 从机 8 位地址（已左移）
  * @retval 0 成功；1 从机无应答
  */
uint8_t MyI2C_WriteBytes(uint8_t Addr, const uint8_t *Buf, uint16_t Len)
{
	uint16_t i;

	MyI2C_Start();
	MyI2C_SendByte(Addr);
	if (MyI2C_ReceiveAck())
	{
		MyI2C_Stop();
		return 1;
	}
	for (i = 0; i < Len; i++)
	{
		MyI2C_SendByte(Buf[i]);
		if (MyI2C_ReceiveAck())
		{
			MyI2C_Stop();
			return 1;
		}
	}
	MyI2C_Stop();
	return 0;
}

/**
  * @brief  连续读多个字节（一个起始位 + 地址 + Len 个数据 + 停止位）
  * @note   最后一个字节回“非应答”，告诉从机停止发送
  * @retval 0 成功；1 从机无应答
  */
uint8_t MyI2C_ReadBytes(uint8_t Addr, uint8_t *Buf, uint16_t Len)
{
	uint16_t i;

	MyI2C_Start();
	MyI2C_SendByte(Addr | 0x01);
	if (MyI2C_ReceiveAck())
	{
		MyI2C_Stop();
		return 1;
	}
	for (i = 0; i < Len; i++)
	{
		Buf[i] = MyI2C_ReceiveByte();
		MyI2C_SendAck((i == Len - 1) ? 1 : 0);
	}
	MyI2C_Stop();
	return 0;
}
