#ifndef __USART_H
#define __USART_H

#include "stm32f10x.h"

/*
 * USART1：PA9 = TX，PA10 = RX，115200 8N1
 * 用途：把测量结果从串口打出来，同时方便用示波器量“串口一个字节”的波形。
 */

void USART1_Init(uint32_t BaudRate);
void USART1_SendByte(uint8_t Byte);
void USART1_SendString(const char *String);
void USART1_SendDec1(int32_t Value10);      /* 发送 1 位小数，253 -> "25.3" */

#endif
