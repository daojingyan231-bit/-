#include "stm32f10x.h"
#include "USART.h"

void USART1_Init(uint32_t BaudRate)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);

	/* PA9 = TX：复用推挽输出 */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* PA10 = RX：上拉输入 */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = BaudRate;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_Init(USART1, &USART_InitStructure);

	USART_Cmd(USART1, ENABLE);
}

void USART1_SendByte(uint8_t Byte)
{
	USART_SendData(USART1, Byte);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}

void USART1_SendString(const char *String)
{
	while (*String != '\0')
	{
		USART1_SendByte((uint8_t)*String);
		String++;
	}
}

void USART1_SendDec1(int32_t Value10)
{
	char Buf[8];
	uint8_t n = 0, i;
	uint32_t Int, Dec;

	if (Value10 < 0)
	{
		USART1_SendByte('-');
		Value10 = -Value10;
	}
	Int = (uint32_t)Value10 / 10;
	Dec = (uint32_t)Value10 % 10;

	if (Int >= 100)
	{
		Buf[n++] = (char)('0' + Int / 100);
	}
	if (Int >= 10)
	{
		Buf[n++] = (char)('0' + (Int / 10) % 10);
	}
	Buf[n++] = (char)('0' + Int % 10);
	Buf[n++] = '.';
	Buf[n++] = (char)('0' + Dec);

	for (i = 0; i < n; i++)
	{
		USART1_SendByte((uint8_t)Buf[i]);
	}
}
