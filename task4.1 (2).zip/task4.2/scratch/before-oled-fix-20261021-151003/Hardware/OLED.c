#define __OLED_C_INTERFACE__
#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "OLED_Font.h"

#if (OLED_USE_SPI == 0)
#include "MyI2C.h"
#endif

uint8_t OLED_GRAM[8][128];

/* ======================= 一、接口层（I2C / SPI 二选一） ======================= */

#if (OLED_USE_SPI == 0)

/* ---------------- 软件 I2C 版 ---------------- */

static void OLED_IF_Init(void)
{
	MyI2C_Init();
}

/**
  * @brief  写命令：控制字节 0x00 + N 条命令，一次完整 I2C 传输
  */
static void OLED_IF_WriteCmd(const uint8_t *Cmd, uint8_t Num)
{
	uint8_t Buf[32];                                /* 控制字节 + 最多 31 条命令 */
	uint8_t i;

	if (Num > 31)
	{
		Num = 31;
	}
	Buf[0] = 0x00;                                  /* 0x00 = 后面是命令 */
	for (i = 0; i < Num; i++)
	{
		Buf[i + 1] = Cmd[i];
	}
	MyI2C_WriteBytes(OLED_ADDR, Buf, (uint16_t)(Num + 1));
}

/**
  * @brief  写数据：控制字节 0x40 + 128 字节显存，一次完整 I2C 传输
  * @note   这就是“整屏一次写完”，波形上看是 1 个起始位 + 1 个控制字节 + 128 字节数据 + 1 个停止位
  */
static void OLED_IF_WriteData(const uint8_t *Data, uint16_t Len)
{
	uint8_t Buf[129];
	uint16_t i;

	if (Len > 128)                                  /* 一页最多 128 列 */
	{
		Len = 128;
	}
	Buf[0] = 0x40;                                  /* 0x40 = 后面是数据 */
	for (i = 0; i < Len; i++)
	{
		Buf[i + 1] = Data[i];
	}
	MyI2C_WriteBytes(OLED_ADDR, Buf, (uint16_t)(Len + 1));
}

#else

/* ---------------- 硬件 SPI1 版 ---------------- */
/* PA5=SCK，PA7=MOSI，PA4=CS，PA6=DC，PA3=RES */

#define OLED_CS(x)      GPIO_WriteBit(GPIOA, GPIO_Pin_4, (BitAction)(x))
#define OLED_DC(x)      GPIO_WriteBit(GPIOA, GPIO_Pin_6, (BitAction)(x))
#define OLED_RES(x)     GPIO_WriteBit(GPIOA, GPIO_Pin_3, (BitAction)(x))

static void OLED_IF_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef SPI_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_SPI1, ENABLE);

	/* CS / DC / RES：普通推挽输出 */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_6;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* SCK / MOSI：复用推挽，由 SPI1 外设驱动 */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_7;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;   /* 只发不收，PA6 就让给 DC */
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;                  /* 空闲低电平 */
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;                /* 第一个边沿采样 */
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_32;  /* 72MHz/32 = 2.25MHz */
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI1, &SPI_InitStructure);
	SPI_Cmd(SPI1, ENABLE);

	OLED_CS(1);
	OLED_DC(1);
	OLED_RES(0);                                    /* 硬件复位 */
	Delay_ms(20);
	OLED_RES(1);
	Delay_ms(20);
}

static void OLED_IF_SendByte(uint8_t Byte)
{
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
	SPI_I2S_SendData(SPI1, Byte);
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) == SET);
}

static void OLED_IF_WriteCmd(const uint8_t *Cmd, uint8_t Num)
{
	uint8_t i;
	OLED_DC(0);                                     /* DC=0：这一批是命令 */
	OLED_CS(0);
	for (i = 0; i < Num; i++)
	{
		OLED_IF_SendByte(Cmd[i]);
	}
	OLED_CS(1);
}

static void OLED_IF_WriteData(const uint8_t *Data, uint16_t Len)
{
	OLED_DC(1);                                     /* DC=1：这一批是显示数据 */
	OLED_CS(0);
	while (Len--)
	{
		OLED_IF_SendByte(*Data++);
	}
	OLED_CS(1);
}

#endif

/* ======================= 二、显示层（与接口无关） ======================= */

/* 初始化命令表：一次发完，波形上是一串连续的命令字节 */
static const uint8_t OLED_InitCmd[] =
{
	0xAE,                   /* 关显示 */
	0x2E,                   /* 关闭硬件滚动 */
	0xD5, 0x80,             /* 时钟分频 */
	0xA8, 0x3F,             /* 多路复用 64 行 */
	0xD3, 0x00,             /* 显示偏移 0 */
	0x40,                   /* 起始行 0 */
	0xA1,                   /* 左右正常 */
	0xC8,                   /* 上下正常 */
	0xDA, 0x12,             /* COM 配置 */
	0x81, 0xCF,             /* 对比度 */
	0xD9, 0xF1,             /* 预充电 */
	0xDB, 0x30,             /* VCOMH */
	0xA4,                   /* 跟随 RAM */
	0xA6,                   /* 正常显示 */
	0x8D, 0x14,             /* 开电荷泵 */
	0xAF                    /* 开显示 */
};

void OLED_Init(void)
{
	OLED_IF_Init();
	Delay_ms(100);
	OLED_IF_WriteCmd(OLED_InitCmd, sizeof(OLED_InitCmd));
	OLED_Clear();
	OLED_Refresh();
}

void OLED_Clear(void)
{
	uint8_t i, j;
	for (j = 0; j < 8; j++)
	{
		for (i = 0; i < 128; i++)
		{
			OLED_GRAM[j][i] = 0x00;
		}
	}
}

/**
  * @brief  整屏刷新：8 页，每页“3 条定位命令 + 128 字节数据”
  * @note   用逻辑分析仪看，会看到 8 组“短命令 + 长数据”的规律波形
  */
void OLED_Refresh(void)
{
	uint8_t Cmd[3];
	uint8_t Page;

	for (Page = 0; Page < 8; Page++)
	{
		Cmd[0] = 0xB0 | Page;       /* 页地址 0~7 */
		Cmd[1] = 0x00;              /* 列地址低 4 位 */
		Cmd[2] = 0x10;              /* 列地址高 4 位 */
		OLED_IF_WriteCmd(Cmd, 3);
		OLED_IF_WriteData(OLED_GRAM[Page], 128);
	}
}

void OLED_SetPixel(int16_t X, int16_t Y, uint8_t Color)
{
	if (X < 0 || X > 127 || Y < 0 || Y > 63)
	{
		return;
	}
	if (Color)
	{
		OLED_GRAM[Y >> 3][X] |= (uint8_t)(1 << (Y & 0x07));
	}
	else
	{
		OLED_GRAM[Y >> 3][X] &= (uint8_t)~(1 << (Y & 0x07));
	}
}

void OLED_DrawChar(int16_t X, int16_t Y, char Char)
{
	uint8_t c, r;
	const uint8_t *Font;

	if (Char < ' ' || Char > '~')
	{
		Char = ' ';
	}
	Font = OLED_F8x16[Char - ' '];

	for (c = 0; c < 8; c++)
	{
		for (r = 0; r < 8; r++)
		{
			if (Font[c] & (1 << r))
			{
				OLED_SetPixel(X + c, Y + r, 1);
			}
			if (Font[c + 8] & (1 << r))
			{
				OLED_SetPixel(X + c, Y + 8 + r, 1);
			}
		}
	}
}

void OLED_DrawString(int16_t X, int16_t Y, const char *String)
{
	while (*String != '\0')
	{
		OLED_DrawChar(X, Y, *String);
		X += 8;
		String++;
	}
}

void OLED_DrawNum(int16_t X, int16_t Y, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
	{
		OLED_DrawChar((int16_t)(X + (Length - 1 - i) * 8), Y, (char)('0' + Number % 10));
		Number /= 10;
	}
}

/**
  * @brief  显示 1 位小数（Value10 是放大 10 倍后的整数，253 -> 25.3）
  */
void OLED_DrawDecimal1(int16_t X, int16_t Y, int32_t Value10)
{
	char Buf[8];
	uint8_t n = 0;
	uint32_t Int, Dec;

	if (Value10 < 0)
	{
		Buf[n++] = '-';
		Value10 = -Value10;
	}
	Int = (uint32_t)Value10 / 10;
	Dec = (uint32_t)Value10 % 10;

	if (Int >= 100)
	{
		Buf[n++] = (char)('0' + Int / 100);
	}
	if (Int >= 10)
	{
		Buf[n++] = (char)('0' + (Int / 10) % 10);
	}
	Buf[n++] = (char)('0' + Int % 10);
	Buf[n++] = '.';
	Buf[n++] = (char)('0' + Dec);
	Buf[n] = '\0';

	OLED_DrawString(X, Y, Buf);
}
