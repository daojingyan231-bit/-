#ifndef __MYI2C_H
#define __MYI2C_H

#include "stm32f10x.h"

/*
 * 软件模拟 I2C（主机）—— OLED 与 AHT20 共用同一条总线
 *
 * 引脚：PB8 = SCL，PB9 = SDA（开漏输出，模块自带上拉电阻）
 * 说明：主控只做“主机”，不需要配置外设 I2C，全部用 GPIO 翻转电平实现，
 *       便于理解和用示波器/逻辑分析仪观察时序（任务2 就是量这个波形）。
 */

void MyI2C_Init(void);
void MyI2C_Start(void);                 /* 起始条件：SCL 高电平期间 SDA 由高变低 */
void MyI2C_Stop(void);                  /* 停止条件：SCL 高电平期间 SDA 由低变高 */
void MyI2C_SendByte(uint8_t Byte);      /* 发送 8 位，高位先行 */
uint8_t MyI2C_ReceiveByte(void);        /* 接收 8 位，高位先行 */
void MyI2C_SendAck(uint8_t AckBit);     /* 发送应答：0=应答，1=非应答 */
uint8_t MyI2C_ReceiveAck(void);         /* 读应答：返回 0 表示从机应答 */

/* 组合操作：一次完整传输（Start + 地址 + 数据 + Stop） */
uint8_t MyI2C_WriteBytes(uint8_t Addr, const uint8_t *Buf, uint16_t Len);  /* 返回 0 表示成功 */
uint8_t MyI2C_ReadBytes(uint8_t Addr, uint8_t *Buf, uint16_t Len);         /* 返回 0 表示成功 */

#endif
