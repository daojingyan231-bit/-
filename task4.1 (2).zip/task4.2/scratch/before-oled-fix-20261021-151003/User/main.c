/*
 * 实验3-OLED显示 · 任务2
 *
 * 要求：用示波器 / 逻辑分析仪测量 I2C、SPI、串口的波形，
 *       理解协议时序，并对照作业代码进行分析。
 *
 * 本工程是“波形激励源”，每 500ms 做一轮：
 *   1) 读一次 AHT20（I2C 0x70）：Start + 0xAC 0x33 0x00 + Stop，等 80ms，
 *      再 Start + 0x71 + 7 字节 + NACK + Stop；
 *   2) 整屏刷新一次 OLED：8 页，每页“3 条定位命令 + 128 字节数据”；
 *   3) 刷新前把 PA0 拉高、刷新完拉低 —— 示波器用 PA0 上升沿单次触发，
 *      抓到的就是完整的一帧刷新波形；
 *   4) 用 TIM2（1MHz）实测这一帧花了多少微秒，显示在屏幕第三行；
 *   5) 串口 115200 8N1 打印 “T=..C,H=..%,frame=..ms”，可对照逻辑分析仪解码。
 *
 * 接口切换：Hardware/OLED.h 里的 OLED_USE_SPI
 *   0 = 软件 I2C（PB8/PB9）      1 = 硬件 SPI1（PA5/PA7，CS=PA4，DC=PA6，RES=PA3）
 *
 * 接线：
 *   I2C：OLED/AHT20  SCL-PB8  SDA-PB9
 *   SPI：D0(SCK)-PA5  D1(MOSI)-PA7  RES-PA3  DC-PA6  CS-PA4
 *   串口：PA9(TX) -> USB 转串口 RXD（共地），115200 8N1
 *   触发：PA0 -> 示波器 EXT / CH3
 */

#include "stm32f10x.h"
#include "Delay.h"
#include "MyI2C.h"
#include "OLED.h"
#include "AHT20.h"
#include "USART.h"

/* ---------------- PA0：同步触发信号 ---------------- */
#define SYNC_HIGH()     GPIO_SetBits(GPIOA, GPIO_Pin_0)
#define SYNC_LOW()      GPIO_ResetBits(GPIOA, GPIO_Pin_0)

/**
  * @brief  TIM2 自由计数器：72MHz / 72 = 1MHz，1 个计数 = 1us
  */
static void Measure_Init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	TIM_TimeBaseStructure.TIM_Period = 0xFFFF;          /* 满量程 65535us */
	TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

	TIM_Cmd(TIM2, ENABLE);
}

static void Sync_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	SYNC_LOW();
}

int main(void)
{
	float Temperature, Humidity;
	int32_t T10, H10, Frame10 = 0, Frame10_Last = 0;
	uint8_t Ret;
	uint16_t Start, Stop, FrameUs;

	Sync_Init();
	Measure_Init();

	OLED_Init();
	MyI2C_Init();                       /* SPI 模式下 OLED_Init 不初始化 I2C，这里保证 AHT20 可用 */
	AHT20_Init();
	USART1_Init(115200);

	while (1)
	{
		/* ---------- 1. 读 AHT20（I2C 地址 0x70） ---------- */
		Ret = AHT20_ReadData(&Temperature, &Humidity);
		if (Ret == 0)
		{
			T10 = (int32_t)(Temperature * 10.0f + ((Temperature >= 0) ? 0.5f : -0.5f));
			H10 = (int32_t)(Humidity * 10.0f + 0.5f);
		}
		else
		{
			T10 = 0;
			H10 = 0;
		}

		/* ---------- 2. 在显存里画好一屏（这一段不产生 I2C 波形） ---------- */
		OLED_Clear();
#if (OLED_USE_SPI == 0)
		OLED_DrawString(0, 0, "BUS: I2C");
#else
		OLED_DrawString(0, 0, "BUS: SPI");
#endif
		if (Ret == 0)
		{
			OLED_DrawString(0, 16, "T:");
			OLED_DrawDecimal1(24, 16, T10);
			OLED_DrawString(64, 16, "C");
			OLED_DrawString(0, 32, "H:");
			OLED_DrawDecimal1(24, 32, H10);
			OLED_DrawString(64, 32, "%");
		}
		else
		{
			OLED_DrawString(0, 16, "T: --.-");
			OLED_DrawString(0, 32, "H: --.-");
		}
		OLED_DrawString(0, 48, "Frame: ");
		OLED_DrawDecimal1(64, 48, Frame10_Last);
		OLED_DrawString(104, 48, "ms");

		/* ---------- 3. 整屏刷新：PA0 高电平区间 = 一帧波形 ---------- */
		SYNC_HIGH();
		Start = TIM2->CNT;
		OLED_Refresh();
		Stop = TIM2->CNT;
		SYNC_LOW();

		FrameUs = (uint16_t)(Stop - Start);  /* 16 位减法自动处理回绕 */
		Frame10 = (int32_t)(FrameUs / 100);  /* 24500us -> 245 -> "24.5ms" */
		Frame10_Last = Frame10;              /* 下一屏显示这次的值 */

		/* ---------- 4. 串口输出，方便和逻辑分析仪的 UART 解码对照 ---------- */
		USART1_SendString("T=");
		USART1_SendDec1(T10);
		USART1_SendString("C,H=");
		USART1_SendDec1(H10);
		USART1_SendString("%,frame=");
		USART1_SendDec1(Frame10);
		USART1_SendString("ms\r\n");

		Delay_ms(500);
	}
}
