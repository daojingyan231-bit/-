#include "u8g2_port.h"
#include "Font8x16.h"
#include "U8G2_CNFont.h"
#include <string.h>

u8g2_t u8g2;                            /* u8g2 实例，含 1KB 显存 */
uint8_t App_OLED_Address = 0x78;
uint8_t App_OLED_Detected = 0;

/* ============================================================
 *  一、byte_cb：u8g2 要发字节时，交给 HAL 的 I2C 发出去
 * ============================================================ */
uint8_t u8x8_byte_hw_i2c(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr)
{
	static uint8_t  s_buf[32];          /* u8g2 的 I2C 分块最大 32 字节 */
	static uint8_t  s_len;
	uint8_t        *data;

	switch (msg)
	{
	case U8X8_MSG_BYTE_SEND:
		/* u8g2 先把数据攒起来，等 END_TRANSFER 时一次发完，减少 I2C 启停开销 */
		data = (uint8_t *)arg_ptr;
		while (arg_int-- > 0)
		{
			if (s_len < sizeof(s_buf))
			{
				s_buf[s_len++] = *data;
			}
			data++;
		}
		break;

	case U8X8_MSG_BYTE_START_TRANSFER:
		s_len = 0;
		break;

	case U8X8_MSG_BYTE_END_TRANSFER:
		/* u8x8_GetI2CAddress() 返回的是“8 位地址”（0x78），正好是 HAL 要的格式 */
		if (HAL_I2C_Master_Transmit(&hi2c1, u8x8_GetI2CAddress(u8x8), s_buf, s_len, 100) != HAL_OK)
		{
			s_len = 0;
			return 0;
		}
		s_len = 0;
		break;

	case U8X8_MSG_BYTE_INIT:
	case U8X8_MSG_BYTE_SET_DC:          /* I2C 没有 DC 线，什么都不用做 */
		break;

	default:
		return 0;
	}
	return 1;
}

/* ============================================================
 *  二、gpio / delay_cb：延时（I2C 方案不需要操作 CS、DC 引脚）
 * ============================================================ */
uint8_t u8x8_gpio_and_delay_stm32(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr)
{
	volatile uint32_t i;

	(void)u8x8;
	(void)arg_ptr;

	switch (msg)
	{
	case U8X8_MSG_GPIO_AND_DELAY_INIT:
		return 1;

	case U8X8_MSG_DELAY_MILLI:
		HAL_Delay(arg_int);
		return 1;

	case U8X8_MSG_DELAY_10MICRO:
		/* 72MHz 下 10us 约 720 个指令周期 */
		for (i = 0; i < (uint32_t)arg_int * 72U; i++)
		{
			__NOP();
		}
		return 1;

	case U8X8_MSG_DELAY_100NANO:
		for (i = 0; i < 7U; i++)
		{
			__NOP();
		}
		return 1;

	case U8X8_MSG_DELAY_NANO:
		__NOP();
		return 1;

	default:
		/* 复位脚、CS、DC 等：本板没有用 GPIO 接这些信号，直接返回“已处理” */
		return 1;
	}
}

/* ============================================================
 *  三、初始化
 * ============================================================ */
void App_Display_Init(void)
{
	/* _f 后缀 = 全屏缓冲（1024 字节），画完 u8g2_SendBuffer() 一次性刷屏 */
	u8g2_Setup_ssd1306_i2c_128x64_noname_f(&u8g2, U8G2_R0,
	                                       u8x8_byte_hw_i2c,
	                                       u8x8_gpio_and_delay_stm32);

	/* 常见 0.96 寸模块的 7 位地址为 0x3C 或 0x3D；HAL 使用左移后的地址。 */
	if (HAL_I2C_IsDeviceReady(&hi2c1, 0x78, 3, 20) == HAL_OK)
	{
		App_OLED_Address = 0x78;
		App_OLED_Detected = 1;
	}
	else if (HAL_I2C_IsDeviceReady(&hi2c1, 0x7A, 3, 20) == HAL_OK)
	{
		App_OLED_Address = 0x7A;
		App_OLED_Detected = 1;
	}
	u8g2_SetI2CAddress(&u8g2, App_OLED_Address);
	u8g2_InitDisplay(&u8g2);
	u8g2_SetPowerSave(&u8g2, 0);
	u8g2_ClearBuffer(&u8g2);
	u8g2_SendBuffer(&u8g2);
}

/* ============================================================
 *  四、文字绘制（小字库 + DrawXBMP）
 * ============================================================ */
static void App_DrawXBM(int16_t X, int16_t Y, uint8_t W, uint8_t H,
                        const uint8_t *Pic, uint8_t Zoom)
{
	uint16_t Row, Col;
	uint16_t Stride = (uint16_t)((W + 7) / 8);

	for (Row = 0; Row < H; Row++)
	{
		for (Col = 0; Col < W; Col++)
		{
			if (Pic[Row * Stride + (Col >> 3)] & (1 << (Col & 0x07)))
			{
				if (Zoom <= 1)
				{
					u8g2_DrawPixel(&u8g2, X + Col, Y + Row);
				}
				else
				{
					u8g2_DrawBox(&u8g2, X + Col * Zoom, Y + Row * Zoom, Zoom, Zoom);
				}
			}
		}
	}
}

void App_DrawChar(int16_t X, int16_t Y, char Char, uint8_t Zoom)
{
	uint8_t Tmp[16];
	uint8_t c, r;
	const uint8_t *Font;

	if (Char < ' ' || Char > '~')
	{
		Char = ' ';
	}
	Font = Font8x16[Char - ' '];

	/* 页格式（列优先）转成 XBM（行优先） */
	for (r = 0; r < 16; r++)
	{
		Tmp[r] = 0x00;
		for (c = 0; c < 8; c++)
		{
			if (Font[(r < 8) ? c : (c + 8)] & (1 << (r & 0x07)))
			{
				Tmp[r] |= (uint8_t)(1 << c);
			}
		}
	}
	App_DrawXBM(X, Y, 8, 16, Tmp, Zoom);
}

void App_DrawStr(int16_t X, int16_t Y, const char *Str, uint8_t Zoom)
{
	if (Zoom == 0)
	{
		Zoom = 1;
	}
	while (*Str != '\0')
	{
		App_DrawChar(X, Y, *Str, Zoom);
		X = (int16_t)(X + 8 * Zoom);
		Str++;
	}
}

void App_DrawCN(int16_t X, int16_t Y, const char *CN, uint8_t Zoom)
{
	uint8_t Tmp[32];
	uint8_t c, r, Found = 0;
	uint16_t n;

	if (Zoom == 0)
	{
		Zoom = 1;
	}

	for (n = 0; n < U8G2_CN16_NUM; n++)
	{
		if (U8G2_CN16[n].Code[0] == CN[0] &&
		    U8G2_CN16[n].Code[1] == CN[1] &&
		    U8G2_CN16[n].Code[2] == CN[2])
		{
			/* 16x16 的 XBM 表已经按行存好，直接用 */
			App_DrawXBM(X, Y, 16, 16, U8G2_CN16[n].Data, Zoom);
			Found = 1;
			break;
		}
	}

	if (!Found)
	{
		/* 字库里没有：画方框提示 */
		u8g2_DrawFrame(&u8g2, X, Y, 16 * Zoom, 16 * Zoom);
		(void)Tmp;
		(void)c;
		(void)r;
	}
}

uint8_t App_StrWidth(const char *Str, uint8_t Zoom)
{
	if (Zoom == 0)
	{
		Zoom = 1;
	}
	return (uint8_t)(strlen(Str) * 8 * Zoom);
}
