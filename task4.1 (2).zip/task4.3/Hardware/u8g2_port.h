#ifndef __U8G2_PORT_H
#define __U8G2_PORT_H

#include "stm32f1xx_hal.h"
#include "u8g2.h"

/*
 * u8g2 在 STM32F103 上的移植层
 *
 *   u8g2 是“上层画图库”，它不直接碰硬件：
 *     - 字节怎么发出去  -> byte_cb    （本文件 u8x8_byte_hw_i2c，用 HAL_I2C 发送）
 *     - 延时、复位脚等  -> gpio/delay_cb（本文件 u8x8_gpio_and_delay_stm32）
 *   把这两个回调注册进去，u8g2_Setup_ssd1306_i2c_128x64_noname_f() 就能工作了。
 */

extern I2C_HandleTypeDef hi2c1;         /* 在 main.c 中定义 */
extern u8g2_t u8g2;                     /* u8g2 实例（全局，占用 1KB 显存） */
extern uint8_t App_OLED_Address;         /* 实际 8 位地址：0x78 或 0x7A */
extern uint8_t App_OLED_Detected;        /* 1=OLED 已应答，0=未应答 */

/* ---- u8g2 需要的两个回调 ---- */
uint8_t u8x8_byte_hw_i2c(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);
uint8_t u8x8_gpio_and_delay_stm32(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);

/* ---- 初始化 u8g2 ---- */
void App_Display_Init(void);

/* ---- 文字：自建小字库 + u8g2_DrawXBMP ----
 * u8g2 官方全字库 u8g2_fonts.c 有 39MB 源码、编译后远超 STM32F103C8T6 的 64KB Flash，
 * 所以这里用“8x16 ASCII + 16x16 汉字”的小字库（等价于 bdfconv 裁剪后的效果），
 * 通过 u8g2 的 DrawXBMP 画出来；Zoom=2 时每个点放大成 2x2，相当于 16x32 大字。
 */
void App_DrawChar(int16_t X, int16_t Y, char Char, uint8_t Zoom);
void App_DrawStr(int16_t X, int16_t Y, const char *Str, uint8_t Zoom);
void App_DrawCN(int16_t X, int16_t Y, const char *CN, uint8_t Zoom);
uint8_t App_StrWidth(const char *Str, uint8_t Zoom);

#endif
