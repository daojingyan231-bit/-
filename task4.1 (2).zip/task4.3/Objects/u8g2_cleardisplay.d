.\objects\u8g2_cleardisplay.o: U8G2\u8g2_cleardisplay.c
.\objects\u8g2_cleardisplay.o: U8G2\u8g2.h
.\objects\u8g2_cleardisplay.o: U8G2\u8x8.h
.\objects\u8g2_cleardisplay.o: D:\dianchang\32\32\keil5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\u8g2_cleardisplay.o: D:\dianchang\32\32\keil5\ARM\ARMCC\Bin\..\include\stdarg.h
.\objects\u8g2_cleardisplay.o: D:\dianchang\32\32\keil5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\u8g2_cleardisplay.o: D:\dianchang\32\32\keil5\ARM\ARMCC\Bin\..\include\limits.h
