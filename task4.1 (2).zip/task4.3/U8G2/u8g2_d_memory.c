/* u8g2_d_memory.c  ——  官方文件精简版
 *
 * 官方 u8g2_d_memory.c 里为每一款屏幕（各种分辨率的 1/2/4 缓冲）都写了一份
 * static 缓冲区，225 个静态数组加起来约 270KB。STM32F103C8T6 只有 20KB RAM，
 * 必须裁剪：本工程只用 0.96 寸 128x64 的“全屏缓冲”模式（_f 后缀），
 * 所以只保留 u8g2_m_16_8_f()（1024 字节）这一个函数。
 *
 * 官方原文件已另存为 u8g2_d_memory_full.c.txt，需要别的屏时从这里抄回去即可。
 */

#include "u8g2.h"

/* 128x64 全屏缓冲：16 个 tile 宽 x 8 个 tile 高 = 1024 字节 */
uint8_t *u8g2_m_16_8_f(uint8_t *page_cnt)
{
  #ifdef U8G2_USE_DYNAMIC_ALLOC
  *page_cnt = 8;
  return 0;
  #else
  static uint8_t buf[1024];
  *page_cnt = 8;
  return buf;
  #endif
}
