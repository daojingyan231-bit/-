/*
 * 实验3-OLED显示 · 任务3：中断服务函数
 *
 * 本工程只需要 1ms 的 SysTick 节拍（HAL_Delay / HAL_GetTick 的时基），
 * 其余中断全部使用启动文件里的弱定义默认实现。
 */

#include "stm32f1xx_hal.h"

void SysTick_Handler(void)
{
	HAL_IncTick();
}
