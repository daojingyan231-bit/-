/*
 * 实验3-OLED显示 · 任务3
 *
 * 要求：用 CubeMX 设计 HAL 库程序框架，下载 u8g2 源码并针对 STM32F103 + 0.96" I2C OLED
 *       做代码裁剪，再移植到 HAL 工程中，完成：
 *       1) u8g2 的 demo 例程；
 *       2) 显示自己的学号（632407030402）和姓名（栖）；
 *       3) 掌握上下、左右滑动显示；
 *       4) 显示一个图案（PASSION + 爱心），带动态效果。
 *
 * 硬件：STM32F103C8T6 + SSD1306 128x64（I2C1：PB6=SCL，PB7=SDA，100kHz）
 *
 * 移植要点：
 *   - 使用 I2C1 默认脚 PB6/PB7，不做引脚重映射；
 *   - u8g2 只通过两个回调碰硬件：u8x8_byte_hw_i2c（发字节）和
 *     u8x8_gpio_and_delay_stm32（延时），都在 Hardware/u8g2_port.c；
 *   - u8g2 官方字库太大，这里用自建 8x16 ASCII + 16x16 汉字，逐点画出来。
 */

#include "stm32f1xx_hal.h"
#include "u8g2_port.h"
#include "HeartPic.h"

/* 汉字（UTF-8 转义，源码保持纯 ASCII） */
#define CN_XUE      "\xE5\xAD\xA6"      /* 学 */
#define CN_HAO      "\xE5\x8F\xB7"      /* 号 */
#define CN_XING     "\xE5\xA7\x93"      /* 姓 */
#define CN_MING     "\xE5\x90\x8D"      /* 名 */
#define CN_QI       "\xE6\xA0\x96"      /* 栖 */

#define ID_STRING   "632407030402"

I2C_HandleTypeDef hi2c1;

/* ---------------- 函数声明 ---------------- */
static void SystemClock_Config(void);
static void MX_I2C1_Init(void);
static void Demo_U8G2_Basic(void);
static void Demo_ID_Name(void);
static void Demo_Scroll(void);
static void Demo_Passion(void);
static void DrawHeart(int16_t cx, int16_t by, int16_t r);
void Error_Handler(void);

/* ============================================================
 *  画面①：u8g2 demo —— 框、进度条、圆、实心圆、三角形、斜线
 * ============================================================ */
static void Demo_U8G2_Basic(void)
{
	uint8_t i;

	for (i = 0; i <= 100; i += 5)
	{
		u8g2_ClearBuffer(&u8g2);

		App_DrawStr(28, 0, "u8g2 DEMO", 1);                 /* 9 字符 = 72 像素 */

		/* 进度条 */
		u8g2_DrawFrame(&u8g2, 4, 22, 120, 14);
		u8g2_DrawBox(&u8g2, 6, 24, (uint8_t)(i * 116 / 100), 10);

		/* 基本图形 */
		u8g2_DrawCircle(&u8g2, 18, 50, 8, U8G2_DRAW_ALL);
		u8g2_DrawDisc(&u8g2, 48, 50, 8, U8G2_DRAW_ALL);
		u8g2_DrawTriangle(&u8g2, 76, 42, 76, 58, 92, 50);
		u8g2_DrawLine(&u8g2, 104, 42, 124, 58);
		u8g2_DrawLine(&u8g2, 124, 42, 104, 58);

		u8g2_SendBuffer(&u8g2);
		HAL_Delay(70);
	}
	HAL_Delay(400);
}

/* ============================================================
 *  画面②：学号 + 姓名
 * ============================================================ */
static void Demo_ID_Name(void)
{
	u8g2_ClearBuffer(&u8g2);

	App_DrawCN(48, 0, CN_XUE, 1);
	App_DrawCN(64, 0, CN_HAO, 1);

	App_DrawStr(16, 20, ID_STRING, 1);        /* 12 位数字 x 8 = 96 像素，居中 */

	App_DrawCN(36, 42, CN_XING, 1);
	App_DrawCN(52, 42, CN_MING, 1);
	App_DrawStr(68, 42, ":", 1);
	App_DrawCN(76, 42, CN_QI, 1);

	u8g2_SendBuffer(&u8g2);
	HAL_Delay(3000);
}

/* ============================================================
 *  画面③：左右滑动 + 上下滑动
 *
 *  u8g2 是显存式绘图：每帧 ClearBuffer -> 在新坐标重画 -> SendBuffer，
 *  坐标逐像素变化就是平滑滚动，上下左右都不受 SSD1306 硬件滚动限制。
 * ============================================================ */
static void Demo_Scroll(void)
{
	int16_t off;
	const char *msg = "just do it";

	/* ---- 左右滑动：文字从右侧进入、左侧离开 ---- */
	for (off = 0; off < 128 + 80; off += 4)
	{
		u8g2_ClearBuffer(&u8g2);
		App_DrawStr(24, 0, "SCROLL L-R", 1);   /* 10 字符 = 80 像素 */
		App_DrawStr((int16_t)(128 - off), 24, msg, 1);

		/* 底部进度条：随滑动进度填充 */
		u8g2_DrawFrame(&u8g2, 0, 46, 128, 16);
		u8g2_DrawBox(&u8g2, 2, 48, (uint8_t)(off * 124 / (128 + 80)), 12);

		u8g2_SendBuffer(&u8g2);
		HAL_Delay(20);
	}

	/* ---- 上下滑动：三行字从底部升上来、从顶部离开 ---- */
	for (off = 0; off < 64 + 3 * 18; off += 2)
	{
		u8g2_ClearBuffer(&u8g2);
		App_DrawStr(8, (int16_t)(64 - off),      "UP-DOWN SCROLL", 1);
		App_DrawStr(8, (int16_t)(64 - off + 18), "u8g2 on F103", 1);
		App_DrawStr(8, (int16_t)(64 - off + 36), ID_STRING, 1);
		u8g2_SendBuffer(&u8g2);
		HAL_Delay(20);
	}
}

/* ============================================================
 *  画面④：PASSION + 爱心（心跳 + 上飘的小爱心）
 * ============================================================ */

/**
  * @brief  用 u8g2 的基本图元拼一个实心爱心：两个圆 + 一个三角形
  * @param  cx 中心横坐标，by 心尖纵坐标，r 半心半径（越大心越大）
  */
static void DrawHeart(int16_t cx, int16_t by, int16_t r)
{
	u8g2_DrawDisc(&u8g2, cx - r, by - 2 * r, r, U8G2_DRAW_ALL);
	u8g2_DrawDisc(&u8g2, cx + r, by - 2 * r, r, U8G2_DRAW_ALL);
	u8g2_DrawTriangle(&u8g2, cx - 2 * r, by - 2 * r, cx + 2 * r, by - 2 * r, cx, by);
}

static void Demo_Passion(void)
{
	uint8_t i, k;
	int16_t r, y;

	for (i = 0; i < 45; i++)
	{
		/* 心跳：半径 6 -> 8 -> 6 循环，形成“扑通扑通”的节奏 */
		k = (uint8_t)(i % 10);
		r = (int16_t)(6 + ((k < 5) ? k : (10 - k)) / 2);

		u8g2_ClearBuffer(&u8g2);
		App_DrawStr(8, 0, "PASSION", 2);            /* 2 倍放大：7 x 16 = 112 像素 */

		DrawHeart(64, 60, r);

		/* 三颗小爱心从下往上飘，超出屏幕自动裁剪 */
		for (k = 0; k < 3; k++)
		{
			y = (int16_t)(58 - ((i * 2 + k * 12) % 26));
			if (y > 36)
			{
				u8g2_DrawXBMP(&u8g2, (int16_t)(12 + k * 44), y, 9, 8, OLED_HeartSmall);
			}
		}

		u8g2_SendBuffer(&u8g2);
		HAL_Delay(70);
	}
}

/* ============================================================
 *  初始化
 * ============================================================ */
static void MX_I2C1_Init(void)
{
	hi2c1.Instance = I2C1;
	hi2c1.Init.ClockSpeed = 100000;                     /* 100kHz 标准模式，面包板接线更稳定 */
	hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
	hi2c1.Init.OwnAddress1 = 0;
	hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	hi2c1.Init.OwnAddress2 = 0;
	hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	if (HAL_I2C_Init(&hi2c1) != HAL_OK)
	{
		Error_Handler();
	}
}

/**
 * @brief  I2C1 引脚初始化：PB6=SCL、PB7=SDA，均为复用开漏
  */
void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	if (hi2c->Instance == I2C1)
	{
		__HAL_RCC_GPIOB_CLK_ENABLE();
		__HAL_RCC_I2C1_CLK_ENABLE();

		GPIO_InitStruct.Pin = GPIO_PIN_6 | GPIO_PIN_7;
		GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;         /* 复用开漏 */
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	}
}

/**
  * @brief  72MHz：HSE 8MHz x 9；HSE 起不来就退回内部 HSI 8MHz
  */
static void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		/* 没有外部晶振时退回 HSI，程序照样能跑（I2C 会慢一点，不影响显示） */
		RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
		RCC_OscInitStruct.HSEState = RCC_HSE_OFF;
		RCC_OscInitStruct.HSIState = RCC_HSI_ON;
		RCC_OscInitStruct.PLL.PLLState = RCC_PLL_OFF;
		if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
		{
			Error_Handler();
		}
		RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
	}
	else
	{
		RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	}

	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
	                              RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;    /* APB1 最高 36MHz */
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
	{
		Error_Handler();
	}
}

void Error_Handler(void)
{
	while (1)
	{
	}
}

int main(void)
{
	HAL_Init();                     /* SysTick 1ms、NVIC 分组 */
	SystemClock_Config();
	MX_I2C1_Init();
	App_Display_Init();             /* u8g2：Setup + InitDisplay + 清屏 */

	while (1)
	{
		Demo_U8G2_Basic();          /* ① u8g2 demo */
		Demo_ID_Name();             /* ② 学号 + 姓名 */
		Demo_Scroll();              /* ③ 左右 + 上下滑动 */
		Demo_Passion();             /* ④ PASSION + 爱心动画 */
	}
}
