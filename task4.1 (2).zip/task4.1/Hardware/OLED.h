#ifndef __OLED_H
#define __OLED_H

#include "stm32f10x.h"

/*
 * SSD1306 0.96 寸 OLED（128x64）驱动
 *   接口：软件 I2C（推荐 PB6=SCL，PB7=SDA；兼容旧 PB8/PB9）
 *   方式：先在 RAM 显存 OLED_GRAM[8][128] 里“画图”，再整屏刷新到屏幕
 *         —— 这叫“显存映射”，画图时不会闪屏，也才能做滑动、动画等效果
 *
 * 坐标：左上角为原点，x 向右 0~127，y 向下 0~63
 */

/* ---------- 屏幕上要用的汉字（UTF-8 转义，源码保持纯 ASCII，避免 Keil 编码问题） ---------- */
#define CN_XING     "\xE5\xA7\x93"      /* 姓 */
#define CN_MING     "\xE5\x90\x8D"      /* 名 */
#define CN_QI       "\xE6\xA0\x96"      /* 栖 */
#define CN_WEN      "\xE6\xB8\xA9"      /* 温 */
#define CN_DU       "\xE5\xBA\xA6"      /* 度 */
#define CN_SHI      "\xE6\xB9\xBF"      /* 湿 */
#define CN_XUE      "\xE5\xAD\xA6"      /* 学 */
#define CN_HAO      "\xE5\x8F\xB7"      /* 号 */
#define CN_ZUO      "\xE5\xB7\xA6"      /* 左 */
#define CN_YOU      "\xE5\x8F\xB3"      /* 右 */
#define CN_HUA      "\xE6\xBB\x91"      /* 滑 */
#define CN_DONG     "\xE5\x8A\xA8"      /* 动 */
#define CN_XIAN     "\xE6\x98\xBE"      /* 显 */
#define CN_SHI2     "\xE7\xA4\xBA"      /* 示 */

/* ---------- 硬件滚动方向 ---------- */
#define OLED_SCROLL_RIGHT   0
#define OLED_SCROLL_LEFT    1

/* 显存：8 页 x 128 列，每字节 8 个像素（bit0 在最上面） */
extern uint8_t OLED_GRAM[8][128];

/* 上电自动识别出来的 I2C 配置（默认 0x78 / PB6-PB7） */
extern uint8_t OLED_Addr;               /* 0x78 或 0x7A */
extern const char *OLED_PinName;        /* 例如 "PB8/PB9" */
extern uint8_t OLED_Detected;           /* 1 = 探测到了 OLED 应答 */

void OLED_Init(void);                                       /* 自动识别引脚+地址，再初始化 SSD1306 */
void OLED_Clear(void);                                      /* 只清显存，不刷新 */
void OLED_Refresh(void);                                    /* 显存整屏刷新（硬件刷屏） */

void OLED_SetPixel(int16_t X, int16_t Y, uint8_t Color);    /* 画点，带边界裁剪 */
void OLED_DrawXBM(int16_t X, int16_t Y, uint8_t W, uint8_t H, const uint8_t *Pic);
void OLED_DrawChar(int16_t X, int16_t Y, char Char);        /* 8x16 ASCII */
void OLED_DrawString(int16_t X, int16_t Y, const char *String);
void OLED_DrawCN(int16_t X, int16_t Y, const char *CN);     /* 16x16 汉字 */
void OLED_DrawNum(int16_t X, int16_t Y, uint32_t Number, uint8_t Length);

/* ---------- 硬件滚动（SSD1306 自带滚动引擎，CPU 不参与） ---------- */
void OLED_HWScroll_Start(uint8_t Dir, uint8_t StartPage, uint8_t EndPage, uint8_t Interval);
void OLED_HWScroll_DiagStart(uint8_t Dir, uint8_t StartPage, uint8_t EndPage, uint8_t VOffset, uint8_t Interval);
void OLED_HWScroll_Stop(void);

/* ---------- 软件滚动（整屏显存平移，可做上下滑动） ---------- */
void OLED_ScrollLeft(uint8_t Num);
void OLED_ScrollRight(uint8_t Num);
void OLED_ScrollUp(uint8_t Num);
void OLED_ScrollDown(uint8_t Num);

#endif
