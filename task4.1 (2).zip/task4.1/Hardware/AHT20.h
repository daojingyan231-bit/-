#ifndef __AHT20_H
#define __AHT20_H

#include "stm32f10x.h"

/*
 * AHT20 温湿度传感器（I2C，地址 0x38，8 位地址 = 0x70）
 * 与 OLED 挂在同一条软件 I2C 总线（PB8/PB9）上，互不冲突。
 *
 * 返回码：
 *   0  成功
 *   1  I2C 无应答（没接好 / 地址不对 / 上拉缺失）
 *   2  测量结果一直忙（超时）
 *   3  CRC 校验错
 *   4  初始化失败（校准位没置起来）
 */

uint8_t AHT20_Init(void);
uint8_t AHT20_ReadData(float *Temperature, float *Humidity);

#endif
