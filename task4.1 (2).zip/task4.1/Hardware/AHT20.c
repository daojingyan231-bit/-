#include "stm32f10x.h"
#include "Delay.h"
#include "MyI2C.h"
#include "AHT20.h"

#define AHT20_ADDR      0x70        /* 0x38 << 1 */
#define AHT20_CMD_INIT  0xBE
#define AHT20_CMD_TRIG  0xAC

/**
  * @brief  读状态字节
  * @param  Status 输出：bit3 = 校准使能（1 表示已校准），bit7 = 忙标志（1 表示正在测量）
  * @retval 0 成功；1 从机无应答（说明总线上没有 AHT20）
  */
static uint8_t AHT20_ReadStatus(uint8_t *Status)
{
	return MyI2C_ReadBytes(AHT20_ADDR, Status, 1);
}

/**
  * @brief  CRC8 校验（多项式 0x31，初值 0xFF，AHT20 数据手册规定）
  */
static uint8_t AHT20_CRC8(const uint8_t *Data, uint8_t Len)
{
	uint8_t i, Byte, Crc = 0xFF;
	while (Len--)
	{
		Byte = *Data++;
		for (i = 0; i < 8; i++)
		{
			if ((Crc ^ Byte) & 0x80)
			{
				Crc = (uint8_t)((Crc << 1) ^ 0x31);
			}
			else
			{
				Crc = (uint8_t)(Crc << 1);
			}
			Byte = (uint8_t)(Byte << 1);
		}
	}
	return Crc;
}

/**
  * @brief  AHT20 初始化：上电后如果没校准，就发 0xBE 0x08 0x00 校准
  * @retval 0 成功，非 0 失败
  */
uint8_t AHT20_Init(void)
{
	uint8_t Cmd[3] = {AHT20_CMD_INIT, 0x08, 0x00};
	uint8_t Status = 0;
	uint8_t i;

	Delay_ms(40);                              /* 上电后至少等 40ms */

	for (i = 0; i < 3; i++)                    /* 最多试 3 次 */
	{
		/* 先读状态：无应答说明总线上没有 AHT20，不能当成“已校准” */
		if (AHT20_ReadStatus(&Status) == 0 && (Status & 0x08) != 0)
		{
			return 0;                          /* 已校准 */
		}
		MyI2C_WriteBytes(AHT20_ADDR, Cmd, 3);  /* 触发校准（无从机时返回 1，忽略） */
		Delay_ms(10);
	}
	return 4;
}

/**
  * @brief  触发一次测量并读出温湿度
  * @param  Temperature 温度，单位 ℃
  * @param  Humidity    相对湿度，单位 %
  * @retval 0 成功
  */
uint8_t AHT20_ReadData(float *Temperature, float *Humidity)
{
	uint8_t Cmd[3] = {AHT20_CMD_TRIG, 0x33, 0x00};
	uint8_t Buf[7];
	uint8_t i;
	uint32_t Raw;

	if (MyI2C_WriteBytes(AHT20_ADDR, Cmd, 3) != 0)
	{
		return 1;
	}
	Delay_ms(80);                              /* 一次测量约 75ms */

	for (i = 0; i < 10; i++)
	{
		if (MyI2C_ReadBytes(AHT20_ADDR, Buf, 7) != 0)
		{
			return 1;
		}
		if ((Buf[0] & 0x80) == 0)              /* bit7 = 0 表示转换完成 */
		{
			break;
		}
		Delay_ms(5);
	}
	if (Buf[0] & 0x80)
	{
		return 2;
	}
	if (AHT20_CRC8(Buf, 6) != Buf[6])
	{
		return 3;
	}

	/* 20 位湿度：Buf[1] Buf[2] + Buf[3] 高 4 位 */
	Raw = ((uint32_t)Buf[1] << 12) | ((uint32_t)Buf[2] << 4) | (Buf[3] >> 4);
	*Humidity = (float)Raw * 100.0f / 1048576.0f;

	/* 20 位温度：Buf[3] 低 4 位 + Buf[4] Buf[5] */
	Raw = (((uint32_t)Buf[3] & 0x0F) << 16) | ((uint32_t)Buf[4] << 8) | Buf[5];
	*Temperature = (float)Raw * 200.0f / 1048576.0f - 50.0f;

	return 0;
}
