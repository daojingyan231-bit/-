/*
 * 实验3-OLED显示 · 任务1
 *
 * 要求：
 *   1) 显示自己的学号（632407030402）和姓名（栖）；
 *   2) 显示 AHT20 的温度和湿度；
 *   3) 上下或左右滑动显示长字符（左右用 SSD1306 硬件滚动）。
 *
 * 硬件：STM32F103C8T6 + 0.96" I2C OLED（SSD1306 128x64）
 *   OLED  VCC-3.3V  GND-GND  SCL-PB8  SDA-PB9
 *   AHT20 VCC-3.3V  GND-GND  SCL-PB8  SDA-PB9（与 OLED 同总线，地址 0x70）
 *
 * 上电流程：
 *   OLED_Init() 自动识别引脚（标准 PB8/PB9 优先）和地址（0x78/0x7A）
 *   -> 自检画面 1.2s -> 四个画面循环
 *
 * 四个画面：
 *   ① 学号 + 姓名
 *   ② AHT20 温湿度（没有传感器时提示后跳过）
 *   ③ 左右滑动（SSD1306 硬件滚动，CPU 不参与）
 *   ④ 上下滑动（整屏显存逐像素平移）
 */

#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "AHT20.h"

#define ID_STRING       "632407030402"      /* 学号 */

/* ---------------- 函数声明 ---------------- */
static void Board_LED_Init(void);
static void Board_LED_Blink(uint8_t Times);
static void Board_LED_Heartbeat(void);
static void Show_Splash(void);
static void Show_ID_Name(void);
static void Show_AHT20(void);
static void Demo_Scroll_LeftRight_HW(void);
static void Demo_Scroll_UpDown_SW(void);
static void DrawDecimal1(int16_t X, int16_t Y, int32_t Value10, const char *Unit);

/**
  * @brief  显示 1 位小数的数值（25.3），后面再跟单位
  * @param  Value10 放大 10 倍后的整数（25.3 -> 253），避免引入 printf 浮点库
  */
static void DrawDecimal1(int16_t X, int16_t Y, int32_t Value10, const char *Unit)
{
	char Buf[10];
	uint8_t n = 0;
	uint32_t Int, Dec;

	if (Value10 < 0)
	{
		Buf[n++] = '-';
		Value10 = -Value10;
	}
	Int = (uint32_t)Value10 / 10;
	Dec = (uint32_t)Value10 % 10;

	if (Int >= 100)
	{
		Buf[n++] = (char)('0' + Int / 100);
	}
	if (Int >= 10)
	{
		Buf[n++] = (char)('0' + (Int / 10) % 10);
	}
	Buf[n++] = (char)('0' + Int % 10);
	Buf[n++] = '.';
	Buf[n++] = (char)('0' + Dec);
	Buf[n] = '\0';

	OLED_DrawString(X, Y, Buf);
	OLED_DrawString((int16_t)(X + n * 8 + 4), Y, Unit);
}

/* ---------------- 板载 LED（PC13，低电平点亮） ---------------- */

static void Board_LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);              /* 熄灭 */
}

/**
  * @brief  “程序在跑、但没找到 OLED”的提示：每秒闪两下
  * @note   看到这个节奏说明单片机正常，问题在 OLED（供电/接线/模块）
  */
static void Board_LED_Heartbeat(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_13);            /* 亮 */
	Delay_ms(80);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);              /* 灭 */
	Delay_ms(120);
	GPIO_ResetBits(GPIOC, GPIO_Pin_13);            /* 亮 */
	Delay_ms(80);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);              /* 灭 */
	Delay_ms(620);
}

/**
  * @brief  连闪 N 次（用于“没探测到 OLED”的提示，闪完照常继续）
  */
static void Board_LED_Blink(uint8_t Times)
{
	while (Times--)
	{
		Board_LED_Heartbeat();
	}
}

/* ---------------- 画面 ---------------- */

/**
  * @brief  开机自检：显示自动识别到的 I2C 引脚和模块地址
  */
static void Show_Splash(void)
{
	OLED_Clear();
	OLED_DrawString(8, 0, "OLED 0.96 I2C");
	OLED_DrawString(8, 22, OLED_PinName);
	OLED_DrawString(8, 44, "ADDR 0x");
	OLED_DrawString(68, 44, (OLED_Addr == 0x7A) ? "7A" : "78");
	OLED_Refresh();
	Delay_ms(1200);
}

/**
  * @brief  画面①：学号 + 姓名
  */
static void Show_ID_Name(void)
{
	OLED_HWScroll_Stop();

	OLED_Clear();
	OLED_DrawCN(48, 0, CN_XUE);         /* 学 */
	OLED_DrawCN(64, 0, CN_HAO);         /* 号 */

	OLED_DrawString(16, 22, ID_STRING); /* 12 位数字 x 8 像素 = 96 像素，居中 */

	OLED_DrawCN(36, 44, CN_XING);       /* 姓 */
	OLED_DrawCN(52, 44, CN_MING);       /* 名 */
	OLED_DrawString(68, 44, ":");
	OLED_DrawCN(76, 44, CN_QI);         /* 栖 */

	OLED_Refresh();
	Delay_ms(3000);
}

/**
  * @brief  画面②：AHT20 温度、湿度，每秒刷新，共 5 秒
  * @note   没有接传感器时显示 AHT20 / NO SENSOR，1.5 秒后跳过
  */
static void Show_AHT20(void)
{
	float Temperature, Humidity;
	int32_t T10, H10;
	uint8_t Ret, i;

	OLED_HWScroll_Stop();

	for (i = 0; i < 5; i++)
	{
		OLED_Clear();
		OLED_DrawCN(40, 0, CN_WEN);     /* 温 */
		OLED_DrawCN(56, 0, CN_SHI);     /* 湿 */
		OLED_DrawCN(72, 0, CN_DU);      /* 度 */

		Ret = AHT20_ReadData(&Temperature, &Humidity);
		if (Ret != 0)
		{
			OLED_DrawString(40, 20, "AHT20");
			OLED_DrawString(28, 40, "NO SENSOR");
			OLED_Refresh();
			Delay_ms(1500);
			return;
		}

		T10 = (int32_t)(Temperature * 10.0f + ((Temperature >= 0) ? 0.5f : -0.5f));
		H10 = (int32_t)(Humidity * 10.0f + 0.5f);

		OLED_DrawString(8, 24, "T:");
		DrawDecimal1(28, 24, T10, "C");
		OLED_DrawString(8, 44, "H:");
		DrawDecimal1(28, 44, H10, "%");

		OLED_Refresh();
		Delay_ms(1000);
	}
}

/**
  * @brief  画面③：左右滑动 —— SSD1306 硬件滚动（0x27 + 0x2F）
  *
  * 硬件滚动由屏幕内部的滚动引擎完成，CPU 发完命令就可以去干别的。
  * 滚动是“128 列环形平移”，所以内容宽度必须正好 128 像素（16 个字符），
  * 这样循环起来才是无缝的；本画面用 "just do it" + 6 个空格。
  * 只让 page3~5（y=24~47）滚动，标题所在的 page0~1 保持静止。
  */
static void Demo_Scroll_LeftRight_HW(void)
{
	OLED_HWScroll_Stop();

	OLED_Clear();
	OLED_DrawCN(32, 0, CN_ZUO);         /* 左 */
	OLED_DrawCN(48, 0, CN_YOU);         /* 右 */
	OLED_DrawCN(64, 0, CN_HUA);         /* 滑 */
	OLED_DrawCN(80, 0, CN_DONG);        /* 动 */

	OLED_DrawString(0, 24, "just do it      ");   /* 10 + 6 = 16 字符 = 128 像素 */
	OLED_Refresh();

	OLED_HWScroll_Start(OLED_SCROLL_LEFT, 3, 5, 0);
	Delay_ms(8000);                     /* 滚动期间 CPU 空闲 */
	OLED_HWScroll_Stop();
}

/**
  * @brief  画面④：上下滑动 —— 整屏显存逐像素平移
  *
  * SSD1306 没有纯垂直的硬件滚动，所以自己搬显存：
  * 每页整体移位，跨页的那一位从相邻页“接力”补进来，就能做到 1 像素平滑移动。
  * 四行字铺满整屏，上移 24 像素再滑回，全程屏上都有内容。
  */
static void Demo_Scroll_UpDown_SW(void)
{
	uint8_t i;

	OLED_HWScroll_Stop();

	OLED_Clear();
	OLED_DrawString(8, 0,  "Scroll Up/Down");
	OLED_DrawString(8, 16, "SW  scrolling");
	OLED_DrawString(8, 32, ID_STRING);
	OLED_DrawString(8, 48, "OLED 0.96 I2C");
	OLED_Refresh();
	Delay_ms(500);

	for (i = 0; i < 24; i++)            /* 上移 24 像素 */
	{
		OLED_ScrollUp(1);
		OLED_Refresh();
		Delay_ms(20);
	}
	for (i = 0; i < 24; i++)            /* 再滑回原位 */
	{
		OLED_ScrollDown(1);
		OLED_Refresh();
		Delay_ms(20);
	}
}

/* ---------------- 主函数 ---------------- */

int main(void)
{
	Board_LED_Init();
	OLED_Init();                        /* 自动识别引脚/地址 + 初始化 SSD1306 */

	if (OLED_Detected == 0)
	{
		/* 没探测到：闪 3 次提示（约 3.6 秒），然后照常初始化显示。
		   探测只是“锦上添花”，不能因为它失败就不点亮屏幕。 */
		Board_LED_Blink(3);
	}

	Show_Splash();
	AHT20_Init();

	while (1)
	{
		Show_ID_Name();                 /* ① 学号 + 姓名 */
		Show_AHT20();                   /* ② 温度 + 湿度 */
		Demo_Scroll_LeftRight_HW();     /* ③ 左右滑动（硬件滚动） */
		Demo_Scroll_UpDown_SW();        /* ④ 上下滑动（软件平移） */
	}
}
