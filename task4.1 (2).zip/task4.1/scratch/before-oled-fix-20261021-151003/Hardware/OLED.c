#include "stm32f10x.h"
#include "Delay.h"
#include "MyI2C.h"
#include "OLED.h"
#include "OLED_Font.h"
#include "OLED_CNFont.h"

uint8_t OLED_GRAM[8][128];          /* 8 页 x 128 列 = 1024 字节显存 */

/*
 * 上电自动识别：数据线插在相邻的哪两个脚、模块地址是 0x78 还是 0x7A。
 * 先试标准接法（PB8/PB9 + 0x78），不成功再试“偏一格/插反”的相邻组合，
 * 这样即使接线差一格，屏幕也能亮起来，并在开机画面里显示实际使用的引脚。
 */
uint8_t OLED_Addr = 0x78;
const char *OLED_PinName = "PB8/PB9";
uint8_t OLED_Detected = 0;           /* 1 = 探测到了 OLED */

typedef struct
{
	uint16_t SclPin;
	uint16_t SdaPin;
	const char *Name;
} OLED_PinPair_TypeDef;

static const OLED_PinPair_TypeDef OLED_PinPairs[] =
{
	{GPIO_Pin_8,  GPIO_Pin_9,  "PB8/PB9"},   /* 标准接法 */
	{GPIO_Pin_9,  GPIO_Pin_8,  "PB9/PB8"},   /* SCL/SDA 插反 */
	{GPIO_Pin_7,  GPIO_Pin_8,  "PB7/PB8"},   /* 整体偏一格 */
	{GPIO_Pin_8,  GPIO_Pin_7,  "PB8/PB7"},
	{GPIO_Pin_6,  GPIO_Pin_7,  "PB6/PB7"},
	{GPIO_Pin_7,  GPIO_Pin_6,  "PB7/PB6"},
	{GPIO_Pin_9,  GPIO_Pin_10, "PB9/PB10"},
	{GPIO_Pin_10, GPIO_Pin_9,  "PB10/PB9"},
};

#define OLED_PINPAIR_NUM   (sizeof(OLED_PinPairs) / sizeof(OLED_PinPairs[0]))

static void OLED_Detect(void)
{
	uint8_t i;

	for (i = 0; i < OLED_PINPAIR_NUM; i++)
	{
		/* 先确认这两根线上真的有模块自带的上拉电阻（4.7k），
		   否则悬空线的电平不可靠，会把“没接”误判成“有应答” */
		if (MyI2C_PinHasPullUp(OLED_PinPairs[i].SclPin) == 0)
		{
			continue;
		}
		if (MyI2C_PinHasPullUp(OLED_PinPairs[i].SdaPin) == 0)
		{
			continue;
		}

		MyI2C_Config(OLED_PinPairs[i].SclPin, OLED_PinPairs[i].SdaPin);

		if (MyI2C_Probe(0x78) == 0)          /* 0x3C << 1 */
		{
			OLED_Addr = 0x78;
			OLED_PinName = OLED_PinPairs[i].Name;
			OLED_Detected = 1;
			return;
		}
		if (MyI2C_Probe(0x7A) == 0)          /* 0x3D << 1 */
		{
			OLED_Addr = 0x7A;
			OLED_PinName = OLED_PinPairs[i].Name;
			OLED_Detected = 1;
			return;
		}
	}

	/* 都没应答：保持默认接法，让后面的初始化照常发出去（屏若存在只是暂时没响应） */
	MyI2C_Config(GPIO_Pin_8, GPIO_Pin_9);
	OLED_Addr = 0x78;
	OLED_PinName = "NOT FOUND";
}

/* ======================= 底层：命令 / 数据 传输 ======================= */

/**
  * @brief  OLED 写 1 条命令
  * @note   控制字节 0x00 表示“后面是命令”
  */
static void OLED_WriteCommand(uint8_t Command)
{
	uint8_t Buf[2];
	Buf[0] = 0x00;
	Buf[1] = Command;
	MyI2C_WriteBytes(OLED_Addr, Buf, 2);
}

/**
  * @brief  OLED 连续写多条命令（一次传输，减少起始/停止位开销）
  */
static void OLED_WriteCommandList(const uint8_t *Command, uint8_t Num)
{
	uint8_t Buf[12];
	uint8_t i;

	if (Num > 11)                       /* 防止 Num 过大时越界读 Buf */
	{
		Num = 11;
	}
	Buf[0] = 0x00;
	for (i = 0; i < Num; i++)
	{
		Buf[i + 1] = Command[i];
	}
	MyI2C_WriteBytes(OLED_Addr, Buf, (uint16_t)(Num + 1));
}

/**
  * @brief  整屏刷新：把 1024 字节显存一次性写进 SSD1306 的 GDDRAM
  *
  * 每页一次 I2C 传输：0x00 + 3 条定位命令 + 0x40 + 128 字节数据
  *  0xB0|page  设置页地址（0~7）
  *  0x10|高4位 列地址高 4 位（这里都是 0）
  *  0x00|低4位 列地址低 4 位（这里都是 0）
  *  0x40       控制字节：后面是数据
  * 这就是题目里说的“硬件刷屏模式”——把整屏数据用连续写的方式灌进去，
  * 而不是每画一个字符就发一次“起始+地址+命令+数据+停止”。
  */
void OLED_Refresh(void)
{
	uint8_t Buf[133];
	uint8_t Page, i;

	for (Page = 0; Page < 8; Page++)
	{
		Buf[0] = 0x00;                  /* 后面 3 字节是命令 */
		Buf[1] = 0xB0 | Page;           /* 页地址 */
		Buf[2] = 0x00;                  /* 列地址低 4 位 = 0 */
		Buf[3] = 0x10;                  /* 列地址高 4 位 = 0 */
		Buf[4] = 0x40;                  /* 后面 128 字节是数据 */
		for (i = 0; i < 128; i++)
		{
			Buf[5 + i] = OLED_GRAM[Page][i];
		}
		MyI2C_WriteBytes(OLED_Addr, Buf, 133);
	}
}

/* ======================= 初始化 ======================= */

void OLED_Init(void)
{
	Delay_ms(100);                      /* 等 OLED 上电稳定 */
	OLED_Detect();                      /* 自动识别引脚（PB8/PB9 优先）和地址（0x78/0x7A） */

	OLED_WriteCommand(0xAE);            /* 关闭显示 */
	OLED_WriteCommand(0xD5);            /* 时钟分频 / 振荡频率 */
	OLED_WriteCommand(0x80);
	OLED_WriteCommand(0xA8);            /* 多路复用率 = 64 行 */
	OLED_WriteCommand(0x3F);
	OLED_WriteCommand(0xD3);            /* 显示偏移 */
	OLED_WriteCommand(0x00);
	OLED_WriteCommand(0x40);            /* 显示起始行 = 0 */
	OLED_WriteCommand(0xA1);            /* 左右方向：0xA1 正常（列地址 127 -> SEG0） */
	OLED_WriteCommand(0xC8);            /* 上下方向：0xC8 正常（COM 反向扫描） */
	OLED_WriteCommand(0xDA);            /* COM 引脚硬件配置 */
	OLED_WriteCommand(0x12);
	OLED_WriteCommand(0x81);            /* 对比度 */
	OLED_WriteCommand(0xCF);
	OLED_WriteCommand(0xD9);            /* 预充电周期 */
	OLED_WriteCommand(0xF1);
	OLED_WriteCommand(0xDB);            /* VCOMH 电压 */
	OLED_WriteCommand(0x30);
	OLED_WriteCommand(0xA4);            /* 输出跟随 RAM 内容（非全亮） */
	OLED_WriteCommand(0xA6);            /* 正常显示（非反色） */
	OLED_WriteCommand(0x8D);            /* 电荷泵 */
	OLED_WriteCommand(0x14);            /* 开启电荷泵 */
	OLED_WriteCommand(0xAF);            /* 开启显示 */

	OLED_Clear();
	OLED_Refresh();
}

/* ======================= 显存操作 ======================= */

void OLED_Clear(void)
{
	uint8_t i, j;
	for (j = 0; j < 8; j++)
	{
		for (i = 0; i < 128; i++)
		{
			OLED_GRAM[j][i] = 0x00;
		}
	}
}

/**
  * @brief  画点（带边界裁剪，坐标超出屏幕就丢弃，不用调用者自己判断）
  * @param  Color 1=亮，0=灭
  */
void OLED_SetPixel(int16_t X, int16_t Y, uint8_t Color)
{
	if (X < 0 || X > 127 || Y < 0 || Y > 63)
	{
		return;
	}
	if (Color)
	{
		OLED_GRAM[Y >> 3][X] |= (uint8_t)(1 << (Y & 0x07));
	}
	else
	{
		OLED_GRAM[Y >> 3][X] &= (uint8_t)~(1 << (Y & 0x07));
	}
}

/**
  * @brief  画 XBM 位图（按行存放、低位在左），可任意坐标，自动裁剪
  * @param  W 图片宽度（像素），H 图片高度（像素）
  */
void OLED_DrawXBM(int16_t X, int16_t Y, uint8_t W, uint8_t H, const uint8_t *Pic)
{
	uint8_t Row, Col;
	uint16_t Stride = (W + 7) / 8;      /* 每行占几个字节 */

	for (Row = 0; Row < H; Row++)
	{
		for (Col = 0; Col < W; Col++)
		{
			if (Pic[Row * Stride + (Col >> 3)] & (1 << (Col & 0x07)))
			{
				OLED_SetPixel(X + Col, Y + Row, 1);
			}
		}
	}
}

/**
  * @brief  显示一个 8x16 ASCII 字符
  * @note   字库 OLED_F8x16 是“页格式”（前 8 字节上半页、后 8 字节下半页、列优先），
  *         这里先转成 XBM 行格式，再走通用的画点流程，这样 y 不必对齐到 8 的整数倍，
  *         滚动、动画时才能逐像素移动。
  */
void OLED_DrawChar(int16_t X, int16_t Y, char Char)
{
	uint8_t Tmp[16];
	uint8_t c, r;
	const uint8_t *Font;

	if (Char < ' ' || Char > '~')
	{
		Char = ' ';
	}
	Font = OLED_F8x16[Char - ' '];

	for (r = 0; r < 16; r++)
	{
		Tmp[r] = 0x00;
		for (c = 0; c < 8; c++)
		{
			if (Font[(r < 8) ? c : (c + 8)] & (1 << (r & 0x07)))
			{
				Tmp[r] |= (uint8_t)(1 << c);
			}
		}
	}
	OLED_DrawXBM(X, Y, 8, 16, Tmp);
}

void OLED_DrawString(int16_t X, int16_t Y, const char *String)
{
	while (*String != '\0')
	{
		OLED_DrawChar(X, Y, *String);
		X += 8;
		String++;
	}
}

/**
  * @brief  显示一个 16x16 汉字
  * @param  CN 指向该汉字 UTF-8 编码的指针，例如 CN_QI
  * @note   字库里找不到就画一个空心方框（方便发现字模缺失）
  */
void OLED_DrawCN(int16_t X, int16_t Y, const char *CN)
{
	uint8_t Tmp[32];
	uint8_t c, r, Found = 0;
	uint16_t n;
	const OLED_CN16_TypeDef *Glyph = 0;

	for (n = 0; n < OLED_CN16_NUM; n++)
	{
		if (OLED_CN16[n].Code[0] == CN[0] &&
			OLED_CN16[n].Code[1] == CN[1] &&
			OLED_CN16[n].Code[2] == CN[2])
		{
			Glyph = &OLED_CN16[n];
			Found = 1;
			break;
		}
	}

	if (!Found)
	{
		/* 字库里没有这个字：画一个 16x16 空心框 */
		for (c = 0; c < 16; c++)
		{
			OLED_SetPixel(X + c, Y, 1);
			OLED_SetPixel(X + c, Y + 15, 1);
			OLED_SetPixel(X, Y + c, 1);
			OLED_SetPixel(X + 15, Y + c, 1);
		}
		return;
	}

	/* 页格式 -> XBM 行格式（16 列 = 2 字节/行） */
	for (r = 0; r < 16; r++)
	{
		Tmp[r * 2] = 0x00;
		Tmp[r * 2 + 1] = 0x00;
		for (c = 0; c < 16; c++)
		{
			if (Glyph->Data[(r < 8) ? c : (16 + c)] & (1 << (r & 0x07)))
			{
				Tmp[r * 2 + (c >> 3)] |= (uint8_t)(1 << (c & 0x07));
			}
		}
	}
	OLED_DrawXBM(X, Y, 16, 16, Tmp);
}

/**
  * @brief  显示无符号数字（右对齐，Length 为显示位数，不足补 0）
  */
void OLED_DrawNum(int16_t X, int16_t Y, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
	{
		OLED_DrawChar(X + (Length - 1 - i) * 8, Y, '0' + Number % 10);
		Number /= 10;
	}
}

/* ======================= 硬件滚动 ======================= */

/**
  * @brief  开启 SSD1306 硬件水平滚动（CPU 不参与，滚动期间可以干别的事）
  * @param  Dir       OLED_SCROLL_LEFT / OLED_SCROLL_RIGHT
  * @param  StartPage 滚动区域起始页（0~7，每页 8 像素）
  * @param  EndPage   滚动区域结束页（0~7）
  * @param  Interval  滚动速度：0=5 帧/列，4=3 帧/列，5=4 帧/列 …… 数值越大越慢
  * @note   只有 StartPage~EndPage 之间的内容会滚动，其余部分保持静止，
  *         所以可以让标题固定、只让下面一行字跑马灯。
  */
void OLED_HWScroll_Start(uint8_t Dir, uint8_t StartPage, uint8_t EndPage, uint8_t Interval)
{
	uint8_t Cmd[7];
	uint8_t Start[2];

	Cmd[0] = (Dir == OLED_SCROLL_LEFT) ? 0x27 : 0x26;   /* 0x26 向右，0x27 向左 */
	Cmd[1] = 0x00;                                      /* 空字节（占位） */
	Cmd[2] = StartPage & 0x07;
	Cmd[3] = Interval & 0x07;
	Cmd[4] = EndPage & 0x07;
	Cmd[5] = 0x00;                                      /* 空字节（占位） */
	Cmd[6] = 0xFF;                                      /* 空字节（占位） */
	OLED_WriteCommandList(Cmd, 7);

	Start[0] = 0x2F;                                    /* 开始滚动 */
	OLED_WriteCommandList(Start, 1);
}

/**
  * @brief  开启“垂直+水平”组合滚动（SSD1306 没有单独的垂直滚动，只能这样组合）
  * @param  VOffset 垂直偏移 0~63，固定不动；水平方向才真正滚动
  */
void OLED_HWScroll_DiagStart(uint8_t Dir, uint8_t StartPage, uint8_t EndPage, uint8_t VOffset, uint8_t Interval)
{
	uint8_t Cmd[8];
	uint8_t Start[2];

	Cmd[0] = (Dir == OLED_SCROLL_LEFT) ? 0x2A : 0x29;   /* 0x29 向右，0x2A 向左 */
	Cmd[1] = 0x00;
	Cmd[2] = StartPage & 0x07;
	Cmd[3] = Interval & 0x07;
	Cmd[4] = EndPage & 0x07;
	Cmd[5] = VOffset & 0x3F;
	Cmd[6] = 0x00;
	Cmd[7] = 0xFF;
	OLED_WriteCommandList(Cmd, 8);

	Start[0] = 0x2F;
	OLED_WriteCommandList(Start, 1);
}

/**
  * @brief  停止硬件滚动
  * @note   停止后显存内容并不复位，重新画一屏再刷新即可恢复
  */
void OLED_HWScroll_Stop(void)
{
	OLED_WriteCommand(0x2E);
}

/* ======================= 软件滚动（整屏显存平移） ======================= */

/* 上移 1 像素：每页每个字节右移 1 位，最低页的数据从下一页的 bit0 补进来 */
static void OLED_ShiftUp1(void)
{
	uint8_t Page, x, Cur;
	for (Page = 0; Page < 8; Page++)
	{
		for (x = 0; x < 128; x++)
		{
			Cur = (uint8_t)(OLED_GRAM[Page][x] >> 1);
			if (Page < 7)
			{
				Cur |= (uint8_t)((OLED_GRAM[Page + 1][x] & 0x01) << 7);
			}
			OLED_GRAM[Page][x] = Cur;
		}
	}
}

/* 下移 1 像素 */
static void OLED_ShiftDown1(void)
{
	int8_t Page;
	uint8_t x, Cur;
	for (Page = 7; Page >= 0; Page--)
	{
		for (x = 0; x < 128; x++)
		{
			Cur = (uint8_t)(OLED_GRAM[Page][x] << 1);
			if (Page > 0)
			{
				Cur |= (uint8_t)((OLED_GRAM[Page - 1][x] & 0x80) >> 7);
			}
			OLED_GRAM[Page][x] = Cur;
		}
	}
}

/* 左移 1 像素 */
static void OLED_ShiftLeft1(void)
{
	uint8_t Page, x;
	for (Page = 0; Page < 8; Page++)
	{
		for (x = 0; x < 127; x++)
		{
			OLED_GRAM[Page][x] = OLED_GRAM[Page][x + 1];
		}
		OLED_GRAM[Page][127] = 0x00;
	}
}

/* 右移 1 像素 */
static void OLED_ShiftRight1(void)
{
	uint8_t Page;
	int8_t x;
	for (Page = 0; Page < 8; Page++)
	{
		for (x = 127; x > 0; x--)
		{
			OLED_GRAM[Page][x] = OLED_GRAM[Page][x - 1];
		}
		OLED_GRAM[Page][0] = 0x00;
	}
}

void OLED_ScrollLeft(uint8_t Num)
{
	while (Num--)
	{
		OLED_ShiftLeft1();
	}
}

void OLED_ScrollRight(uint8_t Num)
{
	while (Num--)
	{
		OLED_ShiftRight1();
	}
}

void OLED_ScrollUp(uint8_t Num)
{
	while (Num--)
	{
		OLED_ShiftUp1();
	}
}

void OLED_ScrollDown(uint8_t Num)
{
	while (Num--)
	{
		OLED_ShiftDown1();
	}
}
