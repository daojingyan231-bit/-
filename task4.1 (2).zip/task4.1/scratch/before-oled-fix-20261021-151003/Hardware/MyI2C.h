#ifndef __MYI2C_H
#define __MYI2C_H

#include "stm32f10x.h"

/*
 * 软件模拟 I2C（主机）—— OLED 与 AHT20 共用同一条总线
 *
 * 默认引脚：PB8 = SCL，PB9 = SDA（开漏输出，模块自带上拉电阻）
 * 说明：主控只做“主机”，不需要配置外设 I2C，全部用 GPIO 翻转电平实现，
 *       便于理解和用示波器/逻辑分析仪观察时序（任务2 就是量这个波形）。
 *
 * 为了容忍“数据线插偏一格/插反”的情况，引脚可以在运行时重新指定：
 * 上电时 OLED_Init() 会用 MyI2C_Probe() 依次试几组相邻引脚，谁有应答就用谁。
 */

void MyI2C_Init(void);                                          /* 默认 PB8/PB9 */
void MyI2C_Config(uint16_t SclPin, uint16_t SdaPin);            /* 运行时指定引脚（GPIO_Pin_x） */
uint8_t MyI2C_Probe(uint8_t Addr);                              /* 探测从机地址，返回 0 表示有应答 */
uint8_t MyI2C_PinHasPullUp(uint16_t Pin);                       /* 该脚上有没有外部上拉（判断线是否真的接着模块） */
void MyI2C_Start(void);                 /* 起始条件：SCL 高电平期间 SDA 由高变低 */
void MyI2C_Stop(void);                  /* 停止条件：SCL 高电平期间 SDA 由低变高 */
void MyI2C_SendByte(uint8_t Byte);      /* 发送 8 位，高位先行 */
uint8_t MyI2C_ReceiveByte(void);        /* 接收 8 位，高位先行 */
void MyI2C_SendAck(uint8_t AckBit);     /* 发送应答：0=应答，1=非应答 */
uint8_t MyI2C_ReceiveAck(void);         /* 读应答：返回 0 表示从机应答 */

/* 组合操作：一次完整传输（Start + 地址 + 数据 + Stop） */
uint8_t MyI2C_WriteBytes(uint8_t Addr, const uint8_t *Buf, uint16_t Len);  /* 返回 0 表示成功 */
uint8_t MyI2C_ReadBytes(uint8_t Addr, uint8_t *Buf, uint16_t Len);         /* 返回 0 表示成功 */

#endif
