/*
 * 任务2.2(1)：中断服务函数
 *
 * 本文件保留本实验用到的两个中断服务函数：
 *   1. SysTick_Handler     —— 1毫秒系统节拍，为 HAL_GetTick() 提供时基；
 *   2. USART1_IRQHandler   —— 串口接收中断入口。
 * 其余异常处理函数使用启动文件中的弱定义默认实现。
 */

#include "stm32f1xx_hal.h"

/* main.c 中定义的串口句柄 */
extern UART_HandleTypeDef huart1;

/**
  * @brief  SysTick 1毫秒节拍中断，供HAL_GetTick()/HAL_Delay()计时使用。
  */
void SysTick_Handler(void)
{
    HAL_IncTick();
}

/**
  * @brief  USART1 中断入口。
  *         HAL_UART_IRQHandler 内部判断中断源（此处为RXNE接收非空）、
  *         清除标志，并在收满指定字节数后回调 HAL_UART_RxCpltCallback()。
  */
void USART1_IRQHandler(void)
{
    HAL_UART_IRQHandler(&huart1);
}
