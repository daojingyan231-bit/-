/*
 * 任务2.2(3)：中断服务函数
 *
 * 本文件保留本实验用到的两个中断服务函数：
 *   1. SysTick_Handler         —— 1毫秒系统节拍，为 HAL_GetTick() 提供时基；
 *   2. DMA1_Channel4_IRQHandler—— DMA1通道4(USART1_TX)传输中断入口。
 * 其余异常处理函数使用启动文件中的弱定义默认实现。
 */

#include "stm32f1xx_hal.h"

/* main.c 中定义的句柄 */
extern UART_HandleTypeDef huart1;
extern DMA_HandleTypeDef  hdma_usart1_tx;

/**
  * @brief  SysTick 1毫秒节拍中断，供HAL_GetTick()/HAL_Delay()计时使用。
  */
void SysTick_Handler(void)
{
    HAL_IncTick();
}

/**
  * @brief  DMA1通道4（USART1_TX）中断入口。
  *         HAL_DMA_IRQHandler 内部判断中断源（传输完成TC等）、清除标志，
  *         并回调 HAL_UART_TxCpltCallback()。
  *         循环模式下每个发送周期触发一次。
  */
void DMA1_Channel4_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&hdma_usart1_tx);
}
