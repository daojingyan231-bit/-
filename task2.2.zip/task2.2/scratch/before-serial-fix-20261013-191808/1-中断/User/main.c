/*
 * 任务2.2(1)：串口中断方式通信（HAL库）
 *
 * 硬件接线（STM32F103C8T6，USB-TTL 模块与单片机交叉相接、共地）：
 *   PA9  (USART1_TX) -> USB-TTL 的 RX
 *   PA10 (USART1_RX) -> USB-TTL 的 TX
 *   GND              -> USB-TTL 的 GND
 *
 * 串口参数：115200 波特率，8 数据位，1 停止位，无校验（8-N-1）
 *
 * 功能说明（用中断方式重做任务2.1 的收发控制）：
 *   1. STM32 连续向上位机(Win10)发送 "hello windows!"（间隔500ms）。
 *   2. 接收改为【中断方式】：USART1 收到一个字节即触发中断，
 *      在 HAL_UART_RxCpltCallback 回调中判断：
 *        上位机发送 '#' -> 暂停发送；
 *        上位机发送 '*' -> 恢复发送。
 *   3. 与轮询方式的区别：发送阻塞期间（HAL_Delay、HAL_UART_Transmit 执行中）
 *      接收依然由中断实时响应，不会漏掉 '#'/'*'，可靠性更高。
 */

#include "stm32f1xx_hal.h"

/* ---------- 运行参数 ---------- */
#define TX_INTERVAL_MS   500U            /* 两次发送之间的间隔 */
#define TX_TIMEOUT_MS    100U            /* 阻塞发送的超时时间 */

/* 发送内容（15字节，不含结尾的'\0'） */
static const uint8_t s_tx_msg[] = "hello windows!\r\n";
/* 发送内容实际长度（sizeof包含结尾'\0'，故减1；避免手写长度写错） */
#define TX_MSG_LEN       (sizeof(s_tx_msg) - 1U)

/* ---------- 全局变量 ---------- */
UART_HandleTypeDef huart1;

volatile uint8_t g_rx_byte   = 0U;       /* 中断接收缓冲（必须为全局变量） */
volatile uint8_t g_tx_enable = 1U;       /* 1=发送中，0=暂停（收到'#'后清零） */

/* ---------- 函数声明 ---------- */
static void SystemClock_Config(void);
static void MX_USART1_UART_Init(void);
void Error_Handler(void);

/**
  * @brief  UART 底层初始化（HAL_UART_Init 内部自动回调）：
  *         开时钟、配置 PA9/PA10 引脚复用、使能 USART1 中断。
  */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef gpio = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();     /* USART1 挂在 APB2 总线(72MHz) */
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* PA9 = USART1_TX：复用推挽输出 */
        gpio.Pin   = GPIO_PIN_9;
        gpio.Mode  = GPIO_MODE_AF_PP;
        gpio.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &gpio);

        /* PA10 = USART1_RX：浮空输入 */
        gpio.Pin   = GPIO_PIN_10;
        gpio.Mode  = GPIO_MODE_INPUT;
        gpio.Pull  = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOA, &gpio);

        /* 使能 USART1 接收中断。
              优先级取1（数值越大优先级越低），低于SysTick(0)，
              不影响 HAL_Delay/HAL_GetTick 的时基 */
        HAL_NVIC_SetPriority(USART1_IRQn, 1U, 0U);
        HAL_NVIC_EnableIRQ(USART1_IRQn);
    }
}

/**
  * @brief  USART1 参数配置：115200-8-N-1，收发模式，无硬件流控。
  */
static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200;                  /* 波特率 115200 */
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;      /* 8位数据 */
    huart1.Init.StopBits     = UART_STOPBITS_1;         /* 1位停止位 */
    huart1.Init.Parity       = UART_PARITY_NONE;        /* 无校验 */
    huart1.Init.Mode         = UART_MODE_TX_RX;         /* 全双工收发 */
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

int main(void)
{
    HAL_Init();                            /* HAL初始化：SysTick 1ms节拍 */
    SystemClock_Config();                  /* 72MHz系统时钟 */
    MX_USART1_UART_Init();                 /* 串口初始化 */

    /* 挂接第一次接收中断：USART1 每收到1个字节就进入一次中断 */
    if (HAL_UART_Receive_IT(&huart1, (uint8_t *)&g_rx_byte, 1U) != HAL_OK)
    {
        Error_Handler();
    }

    while (1)
    {
        /* 主循环只负责发送；接收完全由中断驱动 */
        if (g_tx_enable != 0U)
        {
            HAL_UART_Transmit(&huart1, (uint8_t *)s_tx_msg, TX_MSG_LEN,
                              TX_TIMEOUT_MS);
        }

        HAL_Delay(TX_INTERVAL_MS);
    }
}

/**
  * @brief  串口接收完成回调（由 USART1_IRQHandler -> HAL_UART_IRQHandler 调用）。
  *         收到一个字节后判断 '#'/'*'，并重新挂接收中断准备收下一个字节。
  * @note   必须重新调用 HAL_UART_Receive_IT，否则只能收到1个字符！
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        if (g_rx_byte == '#')
        {
            g_tx_enable = 0U;              /* '#' -> 暂停发送 */
        }
        else if (g_rx_byte == '*')
        {
            g_tx_enable = 1U;              /* '*' -> 恢复发送 */
        }

        /* 重新挂接收中断，继续监听下一个字符 */
        HAL_UART_Receive_IT(&huart1, (uint8_t *)&g_rx_byte, 1U);
    }
}

/**
  * @brief  系统时钟配置：外部8MHz晶振经PLL 9倍频到72MHz；
  *         HSE失败则回退内部HSI。APB1=36MHz，APB2=72MHz。
  *         USART1挂APB2，72MHz/115200=625，波特率无误差。
  */
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType      = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState            = RCC_HSE_ON;
    osc.HSEPredivValue      = RCC_HSE_PREDIV_DIV1;
    osc.LSEState            = RCC_LSE_OFF;
    osc.LSIState            = RCC_LSI_OFF;
    osc.PLL.PLLState        = RCC_PLL_ON;
    osc.PLL.PLLSource       = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL          = RCC_PLL_MUL9;          /* 8MHz x 9 = 72MHz */
    if (HAL_RCC_OscConfig(&osc) != HAL_OK)
    {
        /* HSE启动失败：回退内部HSI 8MHz */
        osc.OscillatorType  = RCC_OSCILLATORTYPE_HSI;
        osc.HSEState        = RCC_HSE_OFF;
        osc.HSIState        = RCC_HSI_ON;
        osc.PLL.PLLState    = RCC_PLL_OFF;
        if (HAL_RCC_OscConfig(&osc) != HAL_OK)
        {
            Error_Handler();
        }
        clk.SYSCLKSource    = RCC_SYSCLKSOURCE_HSI;
    }
    else
    {
        clk.SYSCLKSource    = RCC_SYSCLKSOURCE_PLLCLK;
    }

    clk.ClockType       = RCC_CLOCKTYPE_HCLK   | RCC_CLOCKTYPE_SYSCLK |
                          RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2;
    clk.AHBCLKDivider   = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider  = RCC_HCLK_DIV2;                 /* APB1最高36MHz */
    clk.APB2CLKDivider  = RCC_HCLK_DIV1;                 /* APB2=72MHz */
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief  错误处理：关闭中断并死循环。
  */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        /* 程序异常时停留在此处，便于调试观察 */
    }
}
