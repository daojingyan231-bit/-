/*
 * 任务2.2(3)：串口 DMA 方式连续发送（HAL库）
 *
 * 硬件接线（STM32F103C8T6，USB-TTL 模块与单片机交叉相接、共地）：
 *   PA9  (USART1_TX) -> USB-TTL 的 RX
 *   PA10 (USART1_RX) -> USB-TTL 的 TX
 *   GND              -> USB-TTL 的 GND
 *
 * 串口参数：115200 波特率，8 数据位，1 停止位，无校验（8-N-1）
 *
 * 功能说明：
 *   1. USART1_TX 使用 DMA1 通道4（F103中USART1_TX固定映射到DMA1通道4），
 *      以【循环模式(CIRCULAR)】把内存缓冲区中的数据连续搬运到发送寄存器，
 *      115200bps 持续向上位机(Win10)发送 "hello windows!"。
 *   2. 循环模式下 DMA 由硬件自动无限重发，CPU 发起一次后即可完全不管，
 *      主循环空转——这正是 DMA 相对于查询/中断方式的优势：
 *      不占用 CPU 时间，发送速率也只受波特率限制。
 *      如需更高发送速率，可把 BaudRate 改为 460800 或 921600
 *      （72MHz 主频下均可准确分频）。
 *   3. 若要改为"普通模式+发送完成中断重发"，把 Init.Mode 改为
 *      DMA_NORMAL，并在 HAL_UART_TxCpltCallback() 中重新调用
 *      HAL_UART_Transmit_DMA() 即可。
 */

#include "stm32f1xx_hal.h"

/* ---------- 发送缓冲区（必须为全局/静态变量，DMA直接访问其地址） ---------- */
static uint8_t s_dma_buf[] = "hello windows!\r\n";
#define TX_BUF_LEN   (sizeof(s_dma_buf) - 1U)   /* 实际字节数（去掉结尾'\0'） */

/* ---------- 全局句柄 ---------- */
UART_HandleTypeDef huart1;
DMA_HandleTypeDef  hdma_usart1_tx;

/* ---------- 函数声明 ---------- */
static void SystemClock_Config(void);
static void MX_DMA_Init(void);
static void MX_USART1_UART_Init(void);
void Error_Handler(void);

/**
  * @brief  UART 底层初始化（HAL_UART_Init 内部自动回调）：
  *         开时钟、配置 PA9/PA10 引脚、使能 DMA 发送通道中断。
  */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef gpio = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();     /* USART1 挂在 APB2 总线(72MHz) */
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* PA9 = USART1_TX：复用推挽输出 */
        gpio.Pin   = GPIO_PIN_9;
        gpio.Mode  = GPIO_MODE_AF_PP;
        gpio.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &gpio);

        /* PA10 = USART1_RX：浮空输入（本工程只发不收，仍按标准接法配置） */
        gpio.Pin   = GPIO_PIN_10;
        gpio.Mode  = GPIO_MODE_INPUT;
        gpio.Pull  = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOA, &gpio);

        /* DMA 传输完成中断（循环模式下每个循环周期触发一次） */
        HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 1U, 0U);
        HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);
    }
}

/**
  * @brief  DMA1 通道4 初始化：USART1_TX 专用通道，存储器->外设，循环模式。
  * @note   必须在 MX_USART1_UART_Init() 之前调用（先绑定DMA再初始化UART）。
  */
static void MX_DMA_Init(void)
{
    /* 【重要】STM32F1 的 HAL 库中 HAL_DMA_Init() 不会回调 HAL_DMA_MspInit()
       （该回调在 F1 的 HAL 中并不存在），所以 DMA1 时钟必须在此手动使能，
       否则 DMA 通道不工作、一个字节也发不出去。 */
    __HAL_RCC_DMA1_CLK_ENABLE();

    hdma_usart1_tx.Instance                 = DMA1_Channel4;    /* USART1_TX */
    hdma_usart1_tx.Init.Direction           = DMA_MEMORY_TO_PERIPH;
    hdma_usart1_tx.Init.PeriphInc           = DMA_PINC_DISABLE; /* 外设地址固定 */
    hdma_usart1_tx.Init.MemInc              = DMA_MINC_ENABLE;  /* 内存地址递增 */
    hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart1_tx.Init.MemDataAlignment    = DMA_MDATAALIGN_BYTE;
    hdma_usart1_tx.Init.Mode                = DMA_CIRCULAR;     /* 循环模式 */
    hdma_usart1_tx.Init.Priority            = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
    {
        Error_Handler();
    }

    /* 把DMA句柄绑定到UART句柄的发送通道，HAL_UART_Transmit_DMA才能找到它 */
    __HAL_LINKDMA(&huart1, hdmatx, hdma_usart1_tx);
}

/**
  * @brief  USART1 参数配置：115200-8-N-1，收发模式，无硬件流控。
  */
static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200;                  /* 波特率 115200 */
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;      /* 8位数据 */
    huart1.Init.StopBits     = UART_STOPBITS_1;         /* 1位停止位 */
    huart1.Init.Parity       = UART_PARITY_NONE;        /* 无校验 */
    huart1.Init.Mode         = UART_MODE_TX_RX;         /* 全双工收发 */
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

int main(void)
{
    HAL_Init();                            /* HAL初始化：SysTick 1ms节拍 */
    SystemClock_Config();                  /* 72MHz系统时钟 */

    MX_DMA_Init();                         /* 先初始化DMA并绑定到UART */
    MX_USART1_UART_Init();                 /* 再初始化UART */

    /* 发起一次DMA循环发送，此后硬件自动把缓冲区内容无限重发到USART1 */
    if (HAL_UART_Transmit_DMA(&huart1, s_dma_buf, TX_BUF_LEN) != HAL_OK)
    {
        Error_Handler();
    }

    while (1)
    {
        /* DMA循环模式下CPU无需参与，主循环空转。
              若想改为普通模式，可在此处用标志位+重发逻辑控制 */
        ;
    }
}

/**
  * @brief  DMA1 通道4 传输完成回调（由 DMA1_Channel4_IRQHandler 触发）。
  *         循环模式下每个周期进一次，本实验在此不做处理；
  *         如需统计发送次数/速率，可在此计数。
  */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        /* 循环模式：无需处理，DMA自动开始下一轮搬运 */
    }
}

/**
  * @brief  系统时钟配置：外部8MHz晶振经PLL 9倍频到72MHz；
  *         HSE失败则回退内部HSI。APB1=36MHz，APB2=72MHz。
  *         USART1挂APB2，72MHz/115200=625，波特率无误差。
  */
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType      = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState            = RCC_HSE_ON;
    osc.HSEPredivValue      = RCC_HSE_PREDIV_DIV1;
    osc.LSEState            = RCC_LSE_OFF;
    osc.LSIState            = RCC_LSI_OFF;
    osc.PLL.PLLState        = RCC_PLL_ON;
    osc.PLL.PLLSource       = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL          = RCC_PLL_MUL9;          /* 8MHz x 9 = 72MHz */
    if (HAL_RCC_OscConfig(&osc) != HAL_OK)
    {
        /* HSE启动失败：回退内部HSI 8MHz */
        osc.OscillatorType  = RCC_OSCILLATORTYPE_HSI;
        osc.HSEState        = RCC_HSE_OFF;
        osc.HSIState        = RCC_HSI_ON;
        osc.PLL.PLLState    = RCC_PLL_OFF;
        if (HAL_RCC_OscConfig(&osc) != HAL_OK)
        {
            Error_Handler();
        }
        clk.SYSCLKSource    = RCC_SYSCLKSOURCE_HSI;
    }
    else
    {
        clk.SYSCLKSource    = RCC_SYSCLKSOURCE_PLLCLK;
    }

    clk.ClockType       = RCC_CLOCKTYPE_HCLK   | RCC_CLOCKTYPE_SYSCLK |
                          RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2;
    clk.AHBCLKDivider   = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider  = RCC_HCLK_DIV2;                 /* APB1最高36MHz */
    clk.APB2CLKDivider  = RCC_HCLK_DIV1;                 /* APB2=72MHz */
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief  错误处理：关闭中断并死循环。
  */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        /* 程序异常时停留在此处，便于调试观察 */
    }
}
