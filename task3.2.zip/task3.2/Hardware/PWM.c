#include "stm32f10x.h"                  // Device header

/*==============================================================================
 * PWM 驱动 LED 呼吸灯（任务3.2）
 * ----------------------------------------------------------------------------
 * 使用引脚：PA0 —— TIM2 的通道1（TIM2_CH1）默认复用引脚，无需重映射。
 * 引脚被配置为“复用推挽输出”，由定时器的输出比较单元直接在硬件上产生
 * PWM 方波，软件只需不断修改比较值 CCR 即可改变占空比。
 *
 * 参数与计算（系统时钟 72MHz）：
 *   计数频率 = 72MHz / PSC = 72MHz / 720 = 100kHz
 *   PWM 频率 = 100kHz / ARR = 100kHz / 100 = 1kHz   （周期 1ms，人眼看不到闪烁）
 *   分辨率   = ARR + 1 = 100 级，即占空比可调 0% ~ 100%（步进 1%）
 *
 * 占空比与 CCR 的关系（PWM1 模式 + 高电平有效）：
 *   CCR = 0    -> 占空比 0%   （LED 全灭）
 *   CCR = 100  -> 占空比 100% （LED 全亮）
 *   增大 CCR = 高电平时间变长 = LED 变亮
 *============================================================================*/

/**
  * 函    数：PWM 初始化（TIM2 通道1，输出到 PA0）
  * 参    数：无
  * 返 回 值：无
  */
void PWM_Init(void)
{
	/*开启 TIM2（APB1）和 GPIOA（APB2）的时钟*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	/*PA0 = TIM2_CH1 的默认复用引脚，无需引脚重映射，
	  直接把它配置为“复用推挽输出”，输出的电平就由定时器通道1硬件控制*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;			//复用推挽输出
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;				//PA0
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/*选择内部时钟（72MHz）作为 TIM2 的计数脉冲来源*/
	TIM_InternalClockConfig(TIM2);

	/*时基单元配置：PSC=720-1 -> 100kHz；ARR=100-1 -> PWM 频率 1kHz*/
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;		//向上计数
	TIM_TimeBaseInitStructure.TIM_Period = 100 - 1;						//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 720 - 1;					//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

	/*输出比较单元配置（通道1）*/
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);						//先给结构体赋默认值
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;			//PWM 模式1
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;	//高电平有效
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;	//使能输出
	TIM_OCInitStructure.TIM_Pulse = 0;							//CCR 初值 -> 上电全灭
	TIM_OC1Init(TIM2, &TIM_OCInitStructure);

	/*使能 CCR 的预装载功能：修改 CCR 后，新值在下一个更新事件才生效，
	  这样占空比切换不会出现半周期毛刺，呼吸更平滑*/
	TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);

	/*启动定时器，开始输出 PWM*/
	TIM_Cmd(TIM2, ENABLE);
}

/**
  * 函    数：设置通道1的比较值（即改变占空比）
  * 参    数：Compare 取值范围 0 ~ 100
  *            0   -> 占空比 0%   （最暗）
  *            100 -> 占空比 100% （最亮）
  * 返 回 值：无
  */
void PWM_SetCompare1(uint16_t Compare)
{
	TIM_SetCompare1(TIM2, Compare);
}
