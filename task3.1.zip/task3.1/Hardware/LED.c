#include "stm32f10x.h"                  // Device header
#include "LED.h"

/*==============================================================================
 * LED 驱动（任务3.1）
 * ----------------------------------------------------------------------------
 * 使用引脚：PA0
 *   PA0 是定时器 TIM2 的通道1（TIM2_CH1）的默认复用引脚，本任务把它当作
 *   普通 GPIO 输出使用，LED 的亮灭完全由软件在定时器中断里翻转控制。
 *
 * 接线（高电平点亮）：
 *   PA0 ---- 330Ω 限流电阻 ---- LED 正极(长脚) ---- LED 负极(短脚) ---- GND
 *   即：PA0 输出高电平 -> LED 点亮；PA0 输出低电平 -> LED 熄灭。
 *
 *   如果你的 LED 是按“正极接 3.3V、负极经电阻接 PA0”那种接法（低电平点亮），
 *   只需把下面 LED_ON / LED_OFF 两个函数里的 SetBits / ResetBits 对调即可。
 *============================================================================*/

/**
  * 函    数：LED初始化
  * 参    数：无
  * 返 回 值：无
  */
void LED_Init(void)
{
	/*开启 GPIOA 的时钟（挂在 APB2 总线上）*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	/*将 PA0 配置为 50MHz 通用推挽输出*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		//通用推挽输出
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;				//PA0
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/*上电默认熄灭 LED*/
	LED_OFF();
}

/**
  * 函    数：点亮LED
  * 参    数：无
  * 返 回 值：无
  */
void LED_ON(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_0);		//PA0 输出高电平
}

/**
  * 函    数：熄灭LED
  * 参    数：无
  * 返 回 值：无
  */
void LED_OFF(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_0);		//PA0 输出低电平
}

/**
  * 函    数：翻转LED状态（亮->灭，灭->亮）
  * 参    数：无
  * 返 回 值：无
  */
void LED_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_0) == 0)		//当前输出低电平（灭）
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_0);					//则改为高电平（亮）
	}
	else													//当前输出高电平（亮）
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_0);					//则改为低电平（灭）
	}
}
