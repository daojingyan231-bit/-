#include "stm32f10x.h"                  // Device header
#include "LED.h"

/*==============================================================================
 * TIM2 定时中断（任务3.1）
 * ----------------------------------------------------------------------------
 * 思路：让 TIM2 以“计数溢出”的方式工作，每计满 1s 就产生一次更新中断，
 *       在中断服务函数里把 LED 翻转一次。
 *       翻转周期 1s  ->  LED 亮 1s、灭 1s，完整亮-灭周期 = 2s。
 *
 * 时钟计算（系统时钟 72MHz）：
 *   TIM2 挂在 APB1 上，APB1 分频系数为 2（36MHz），
 *   但定时器时钟会被硬件自动倍频：TIM2_CLK = 72MHz。
 *      计数频率 = 72MHz / PSC = 72MHz / 7200   = 10kHz
 *      更新周期 = 1 / (10kHz / ARR) = 10000/10kHz = 1s
 *============================================================================*/

/**
  * 函    数：定时器初始化（TIM2 更新中断，1s 一次）
  * 参    数：无
  * 返 回 值：无
  */
void Timer_Init(void)
{
	/*开启 TIM2 的时钟（TIM2 挂在 APB1 总线上）*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	/*选择内部时钟（72MHz）作为 TIM2 的计数脉冲来源*/
	TIM_InternalClockConfig(TIM2);

	/*时基单元配置*/
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;		//时钟分频，不影响计数
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;	//向上计数
	TIM_TimeBaseInitStructure.TIM_Period = 10000 - 1;				//ARR 自动重装值 -> 1s
	TIM_TimeBaseInitStructure.TIM_Prescaler = 7200 - 1;				//PSC 预分频值 -> 10kHz
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

	/*TIM_TimeBaseInit 内部会产生一次更新事件、置位更新标志，
	  先清掉它，避免初始化完成后立刻误进一次中断*/
	TIM_ClearFlag(TIM2, TIM_FLAG_Update);

	/*使能 TIM2 的更新中断*/
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

	/*NVIC 配置：使能 TIM2 中断通道，允许它打断主程序*/
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);

	/*启动定时器，开始计数*/
	TIM_Cmd(TIM2, ENABLE);
}

/**
  * 函    数：TIM2 更新中断服务函数
  * 说    明：每计满 1s 进入一次，把 LED 翻转一次，
  *           因此 LED 的完整“亮-灭”周期为 2s。
  * 参    数：无
  * 返 回 值：无
  */
void TIM2_IRQHandler(void)
{
	/*判断是否为 TIM2 更新中断*/
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
		LED_Turn();										//翻转 LED 亮灭状态
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);		//清除中断标志位
	}
}
