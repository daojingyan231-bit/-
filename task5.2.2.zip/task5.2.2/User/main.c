/*
 * 实验5 · 任务5.2.2
 * 基于 I2C 协议的 AHT20 温湿度采集（裸机 / 前后台程序），串口输出
 *
 * 题目要求（实验4 任务二）：
 *   “学习 I2C 总线通信协议，使用 STM32F103 完成基于 I2C 协议的 AHT20 温湿度传感器的数据采集，
 *     并将采集的温度-湿度值通过串口输出。……阅读 AHT20 数据手册，编程实现：
 *     每隔 2 秒钟采集一次温湿度数据，并通过串口发送到上位机（Win10）。”
 *
 * 本工程是任务二的第 2 小问（裸机版）：
 *   不用 RTOS，main() 里 while(1) 循环：读 AHT20 -> 串口打印 -> 延时 2 秒。
 *   第 3 小问“把 RTOS 的第 3 个任务改成温湿度采集”见 task5.2.3。
 *
 * 硬件接线：
 *   AHT20  VCC -> 3.3V
 *          GND -> GND
 *          SCL -> PB6
 *          SDA -> PB7
 *   模块自带上拉电阻；若自己搭板，SCL/SDA 各接 4.7k 上拉到 3.3V。
 *   串口   PA9(TX) -> DAP-LINK串口RX，PA10(RX) -> 串口TX，GND共地，115200 8N1。
 *   LED1   3.3V -> 220~330Ω -> LED正极 -> LED负极 -> PA1（低电平点亮）。
 *
 * 输出格式（ASCII，任何串口助手都能看）：
 *   No.1  T=25.3 C, H=60.2 %
 *   No.2  T=25.4 C, H=60.1 %
 *   没接传感器时：No.1  AHT20 error=1
 *
 * AHT20 驱动：Hardware/AHT20.c（校准、触发测量、20 位数据、CRC8 校验）
 * I2C 驱动：Hardware/MyI2C.c（软件模拟 I2C，PB6=SCL，PB7=SDA）
 */

#include "stm32f10x.h"
#include "Delay.h"
#include "LED.h"
#include "USART.h"
#include "MyI2C.h"
#include "AHT20.h"

/* ---------------- 板载 PC13 指示灯（低电平点亮） ---------------- */
static void BoardLed_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);
}

/* 每采集一次翻转一次板载灯，表示“程序在跑、正在采样” */
static void BoardLed_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13) == 0)
	{
		GPIO_SetBits(GPIOC, GPIO_Pin_13);
	}
	else
	{
		GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	}
}

/* ---------------- 串口横幅 ---------------- */
static void PrintBanner(void)
{
	USART1_SendString("\r\n");
	USART1_SendString("==================================================\r\n");
	USART1_SendString(" Experiment 5 - Task 5.2.2\r\n");
	USART1_SendString(" AHT20 temperature/humidity sampling (bare-metal)\r\n");
	USART1_SendString(" MCU  : STM32F103C8T6 @72MHz\r\n");
	USART1_SendString(" AHT20: I2C addr 0x38, SCL=PB6, SDA=PB7\r\n");
	USART1_SendString(" UART : PA9(TX) 115200 8N1\r\n");
	USART1_SendString(" Period: 2s, output: No.n T=xx.x C, H=xx.x %\r\n");
	USART1_SendString("==================================================\r\n");
}

/**
  * @brief  把浮点温度/湿度四舍五入成“放大 10 倍的整数”，避免 printf 浮点库
  * @param  Value 温度或湿度
  * @retval Value * 10（保留 1 位小数）
  */
static int32_t ToTenth(float Value)
{
	if (Value >= 0.0f)
	{
		return (int32_t)(Value * 10.0f + 0.5f);
	}
	return (int32_t)(Value * 10.0f - 0.5f);
}

int main(void)
{
	float Temperature, Humidity;
	uint32_t Count = 0;
	uint8_t Ret;
	uint8_t Inited = 0;

	Delay_Init();
	USART1_Init(115200);
	LED_Init();
	LED1_OFF();
	LED2_OFF();
	BoardLed_Init();

	PrintBanner();

	/* 使用 I2C1 默认引脚：PB6=SCL，PB7=SDA。 */
	MyI2C_Config(GPIO_Pin_6, GPIO_Pin_7);

	Ret = AHT20_Init();
	if (Ret == 0)
	{
		Inited = 1;
		USART1_SendString("[AHT20] init OK\r\n");
	}
	else
	{
		USART1_SendString("[AHT20] init failed, code=");
		USART1_SendUnsigned(Ret);
		USART1_SendString(" (check 3.3V / PB6 / PB7)\r\n");
	}

	while (1)
	{
		Count++;

		Ret = AHT20_ReadData(&Temperature, &Humidity);

		if ((Ret == 0) && (Inited == 0))
		{
			Inited = 1;                                  /* 热插拔后自动恢复 */
			USART1_SendString("[AHT20] sensor online\r\n");
		}

		USART1_SendString("No.");
		USART1_SendUnsigned(Count);
		USART1_SendString("  ");

		if (Ret == 0)
		{
			USART1_SendString("T=");
			USART1_SendDec1(ToTenth(Temperature));
			USART1_SendString(" C, H=");
			USART1_SendDec1(ToTenth(Humidity));
			USART1_SendString(" %");
			USART1_SendNewLine();

			LED1_Turn();                                 /* 每采到一次翻转一次 */
			BoardLed_Turn();
		}
		else
		{
			USART1_SendString("AHT20 error=");
			USART1_SendUnsigned(Ret);
			USART1_SendNewLine();
			BoardLed_Turn();
		}

		Delay_ms(2000);                                  /* 每 2 秒采集一次 */
	}
}
