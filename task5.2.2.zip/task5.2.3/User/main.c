/*
 * 实验5 · 任务5.2.3
 * 在 uC/OS-II 多任务程序里，把第 3 个任务改成“每 2 秒采集一次 AHT20 并串口输出”
 *
 * 题目要求（实验4 任务二第 3 小问）：
 *   “在任务一多任务程序完成基础上，把第 3 个 task 改为每隔 2 秒钟采集一次温湿度数据，
 *     并通过串口发送到上位机（Win10）。”
 *
 * 本工程按任务一的 3 任务结构：保留 LED1（1s）、LED2（3s），
 * 把第 3 个任务改成 AHT20 温湿度采集（原第 3 个任务是每 2s 发 hello）：
 *   第 3 个任务：初始化 AHT20 -> 每 2s 读一次温湿度 -> 串口打印 "No.n T=.. C, H=.. %"。
 *
 * 为什么 RTOS 下更“舒服”：
 *   AHT20 一次测量要等约 80ms。裸机版 Delay_ms(80) 是死等，CPU 白转；
 *   本工程的 Delay_ms() 在 OSRunning 之后会自动调用 OSTimeDly()，
 *   等待期间 CPU 去跑 LED 任务，时间到了再回来读数据。
 *
 * 硬件接线：
 *   AHT20  VCC -> 3.3V, GND -> GND, SCL -> PB6, SDA -> PB7
 *   串口   PA9(TX) -> DAP-LINK串口RX，PA10(RX) -> 串口TX，GND共地，115200 8N1
 *   LED采用低电平点亮：3.3V -> 220~330Ω -> LED正极 -> LED负极 -> PA1/PA2
 */

#include "stm32f10x.h"
#include "os.h"
#include "cpu.h"
#include "Delay.h"
#include "LED.h"
#include "USART.h"
#include "MyI2C.h"
#include "AHT20.h"

/* ---------------- 任务优先级与栈大小 ---------------- */
#define START_TASK_PRIO     5u
#define LED1_TASK_PRIO      6u
#define LED2_TASK_PRIO      7u
#define AHT_TASK_PRIO       8u

#define START_STK_SIZE      128u
#define LED_STK_SIZE        96u
#define AHT_STK_SIZE        192u

static OS_STK StartTaskStk[START_STK_SIZE];
static OS_STK Led1TaskStk[LED_STK_SIZE];
static OS_STK Led2TaskStk[LED_STK_SIZE];
static OS_STK AhtTaskStk[AHT_STK_SIZE];

static void StartTask(void *pdata);
static void Led1Task(void *pdata);
static void Led2Task(void *pdata);
static void AhtTask(void *pdata);

/* ---------------- 板载 PC13 指示灯（低电平点亮） ---------------- */
static void BoardLed_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);
}

static void BoardLed_On(void)  { GPIO_ResetBits(GPIOC, GPIO_Pin_13); }
static void BoardLed_Off(void) { GPIO_SetBits(GPIOC, GPIO_Pin_13); }

/* ---------------- 串口横幅 ---------------- */
static void PrintBanner(void)
{
	USART1_SendString("\r\n");
	USART1_SendString("==================================================\r\n");
	USART1_SendString(" Experiment 5 - Task 5.2.3\r\n");
	USART1_SendString(" uC/OS-II + AHT20: task 3 samples T/H every 2s\r\n");
	USART1_SendString(" MCU : STM32F103C8T6 @72MHz\r\n");
	USART1_SendString(" OS  : uC/OS-II V2.93.01, tick = 1ms\r\n");
	USART1_SendString(" Task1: LED1 PA1, 1s, prio 6\r\n");
	USART1_SendString(" Task2: LED2 PA2, 3s, prio 7\r\n");
	USART1_SendString(" Task3: AHT20 PB6/PB7, 2s, prio 8\r\n");
	USART1_SendString(" UART : PA9(TX) 115200 8N1\r\n");
	USART1_SendString("==================================================\r\n");
}

/**
  * @brief  浮点转“放大 10 倍的整数”，四舍五入，避免 printf 浮点库
  */
static int32_t ToTenth(float Value)
{
	if (Value >= 0.0f)
	{
		return (int32_t)(Value * 10.0f + 0.5f);
	}
	return (int32_t)(Value * 10.0f - 0.5f);
}

int main(void)
{
	Delay_Init();
	USART1_Init(115200);
	LED_Init();
	BoardLed_Init();

	/* 使用 I2C1 默认引脚 PB6=SCL / PB7=SDA。 */
	MyI2C_Config(GPIO_Pin_6, GPIO_Pin_7);

	PrintBanner();

	OSInit();
	OSTaskCreate(StartTask,
	             (void *)0,
	             &StartTaskStk[START_STK_SIZE - 1u],
	             START_TASK_PRIO);

	OSStart();

	while (1)
	{
	}
}

/**
  * @brief  启动任务：创建 3 个任务，启动 SysTick 节拍，然后挂起自己
  */
static void StartTask(void *pdata)
{
	(void)pdata;

	OSTaskCreate(Led1Task, (void *)0, &Led1TaskStk[LED_STK_SIZE - 1u], LED1_TASK_PRIO);
	OSTaskCreate(Led2Task, (void *)0, &Led2TaskStk[LED_STK_SIZE - 1u], LED2_TASK_PRIO);
	OSTaskCreate(AhtTask,  (void *)0, &AhtTaskStk[AHT_STK_SIZE - 1u], AHT_TASK_PRIO);

	OS_CPU_SysTickInit(SystemCoreClock / OS_TICKS_PER_SEC);

	USART1_SendString("[OS] scheduler started, 3 tasks are running\r\n");

	OSTaskSuspend(OS_PRIO_SELF);
}

/**
  * @brief  任务 1：LED1 1s 周期闪烁
  */
static void Led1Task(void *pdata)
{
	(void)pdata;

	while (1)
	{
		LED1_ON();
		BoardLed_On();
		OSTimeDly(500);

		LED1_OFF();
		BoardLed_Off();
		OSTimeDly(500);
	}
}

/**
  * @brief  任务 2：LED2 3s 周期闪烁
  */
static void Led2Task(void *pdata)
{
	(void)pdata;

	while (1)
	{
		LED2_ON();
		OSTimeDly(1500);

		LED2_OFF();
		OSTimeDly(1500);
	}
}

/**
  * @brief  任务 3：AHT20 温湿度采集，每 2 秒一次，串口输出
  */
static void AhtTask(void *pdata)
{
	float Temperature, Humidity;
	uint32_t Count = 0;
	uint8_t Ret;
	uint8_t Inited = 0;

	(void)pdata;

	USART1_SendString("[AHT20] task started\r\n");

	while (1)
	{
		if (Inited == 0)
		{
			Ret = AHT20_Init();
			if (Ret == 0)
			{
				Inited = 1;
				USART1_SendString("[AHT20] init OK\r\n");
			}
			else
			{
				USART1_SendString("[AHT20] init failed, code=");
				USART1_SendUnsigned(Ret);
				USART1_SendString(" (check 3.3V / PB6 / PB7)\r\n");
			}
		}

		Count++;
		Ret = AHT20_ReadData(&Temperature, &Humidity);

		USART1_SendString("No.");
		USART1_SendUnsigned(Count);
		USART1_SendString("  ");

		if (Ret == 0)
		{
			Inited = 1;
			USART1_SendString("T=");
			USART1_SendDec1(ToTenth(Temperature));
			USART1_SendString(" C, H=");
			USART1_SendDec1(ToTenth(Humidity));
			USART1_SendString(" %");
			USART1_SendNewLine();
		}
		else
		{
			USART1_SendString("AHT20 error=");
			USART1_SendUnsigned(Ret);
			USART1_SendNewLine();
		}

		OSTimeDly(2000);          /* 2s 后再采，等待期间 LED 任务照常运行 */
	}
}
