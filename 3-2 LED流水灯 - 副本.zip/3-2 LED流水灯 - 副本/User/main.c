/* STM32F103C8T6 寄存器方式流水灯
 * 流程：蓝(PC14) -> 红(PA0) -> 绿(PB0) -> 板载灯(PC13)，各亮1秒循环。
 *
 * 接线：
 *   外接三灯（蓝/红/绿）：GPIO -> 限流电阻(红绿330欧，蓝1千欧) -> LED阳极 -> LED阴极 -> GND，
 *   即高电平点亮。
 *   板载灯 PC13：LED阳极经电阻接3.3V、阴极接PC13，即低电平点亮。
 *
 * 关键寄存器 / 地址（参考 RM0008）：
 *   RCC_APB2ENR  0x40021018  bit2/3/4 分别使能 GPIOA/B/C 时钟
 *   GPIOA        0x40010800
 *   GPIOB        0x40010C00
 *   GPIOC        0x40011000
 *     CRL  +0x00  引脚0~7 配置，每脚4位
 *     CRH  +0x04  引脚8~15 配置，每脚4位
 *     BSRR +0x10  低16位写1置高；高16位写1置低（免读改写）
 *   SysTick CTRL/LOAD/VAL = 0xE000E010 / 0xE000E014 / 0xE000E018
 */

#include "stm32f10x.h"

/* ===== 每个灯的开关：直接写 BSRR，屏蔽高低电平差异 ===== */
#define RED_ON()    (GPIOA->BSRR = (1UL << 0))          /* PA0 高电平亮   */
#define RED_OFF()   (GPIOA->BSRR = (1UL << 0)  << 16)
#define GREEN_ON()  (GPIOB->BSRR = (1UL << 0))          /* PB0 高电平亮   */
#define GREEN_OFF() (GPIOB->BSRR = (1UL << 0)  << 16)
#define BLUE_ON()   (GPIOC->BSRR = (1UL << 14))         /* PC14 高电平亮  */
#define BLUE_OFF()  (GPIOC->BSRR = (1UL << 14) << 16)
#define BOARD_ON()  (GPIOC->BSRR = (1UL << 13) << 16)   /* PC13 低电平亮  */
#define BOARD_OFF() (GPIOC->BSRR = (1UL << 13))

#define ALL_OFF()   do { RED_OFF(); GREEN_OFF(); BLUE_OFF(); BOARD_OFF(); } while (0)

/* 初始化：开时钟 -> 预灭 -> 配置输出 */
static void LED_Init(void)
{
    /* 1) 开 GPIOA/B/C 时钟（RCC_APB2ENR bit2/3/4） */
    RCC->APB2ENR |= (1UL << 2) | (1UL << 3) | (1UL << 4);
    (void)RCC->APB2ENR;                 /* 回读确保写入完成 */

    /* 2) 配置成输出前先全部熄灭，避免初始化瞬间 LED 短暂全亮 */
    ALL_OFF();

    /* 3) PA0 / PB0：CRL 每脚4位 = [CNF1 CNF0 MODE1 MODE0]
     *    0x2 = 0010b：通用推挽输出，速度2MHz。只动本脚的4位。 */
    GPIOA->CRL = (GPIOA->CRL & ~0x0FUL)          | 0x2UL;
    GPIOB->CRL = (GPIOB->CRL & ~0x0FUL)          | 0x2UL;

    /* 4) PC13 / PC14 在 CRH，位偏移分别为 (13-8)*4=20、(14-8)*4=24 */
    GPIOC->CRH = (GPIOC->CRH & ~(0x0FUL << 20 | 0x0FUL << 24))
                             |  (0x2UL  << 20 | 0x2UL  << 24);
}

/* SysTick 毫秒延时（轮询 COUNTFLAG，不用中断）
 * LOAD 按当前 HCLK 计算，8MHz 或 72MHz 都准确；
 * 24位计数器装不下1秒，故按1ms一次循环1000次。
 */
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SysTick->CTRL = 0UL;
        SysTick->LOAD = SystemCoreClock / 1000UL - 1UL;
        SysTick->VAL  = 0UL;
        SysTick->CTRL = 5UL;                    /* HCLK源，无中断，启动 */
        while ((SysTick->CTRL & (1UL << 16)) == 0UL)
        {
            /* 等待 COUNTFLAG=1，本毫秒计数完成 */
        }
        SysTick->CTRL = 0UL;
    }
}

int main(void)
{
    SystemCoreClockUpdate();                     /* 更新 SystemCoreClock 变量 */
    LED_Init();

    while (1)
    {
        ALL_OFF();  BLUE_ON();  Delay_ms(1000);  /* 第1秒：蓝灯亮   */
        ALL_OFF();  RED_ON();   Delay_ms(1000);  /* 第2秒：红灯亮   */
        ALL_OFF();  GREEN_ON(); Delay_ms(1000);  /* 第3秒：绿灯亮   */
        ALL_OFF();  BOARD_ON(); Delay_ms(1000);  /* 第4秒：板载灯亮 */
    }
}