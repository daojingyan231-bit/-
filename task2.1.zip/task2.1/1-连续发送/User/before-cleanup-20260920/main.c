

#include "stm32f10x.h"

/* ===== 用户可调参数 ===== */
#define LED_ACTIVE_HIGH   1U     /* 外接 LED 极性：1=高电平点亮；0=低电平点亮 */
#define BOARD_ACTIVE_HIGH 0U     /* 板载 PC13 极性：固定 0=低电平点亮 */
#define INCLUDE_BOARD_LED  1U     /* 1=把板载 PC13 也加入流水灯 */
#define DIAG_MODE         0U     /* 1=自检模式：所有 LED 一起快闪 */

/* 引脚掩码 */
#define RED_PIN    (1UL << 0)    /* PA0  红灯 */
#define GREEN_PIN  (1UL << 0)    /* PB0  绿灯 */
#define BLUE_PIN   (1UL << 14)   /* PC14 蓝灯（若被LSE晶振占用可改成 (1UL<<13)） */
#define BOARD_PIN  (1UL << 13)   /* PC13 板载灯 */

/* ===== BSRR 抽象：写入一个引脚的高低电平，参数化点亮极性 =====
 * on       : 1=要点亮，0=要熄灭
 * activeHi : 1=高电平点亮，0=低电平点亮
 */
static void LED_SetLevel(GPIO_TypeDef *port, uint16_t pinMask, uint8_t activeHi, uint8_t on)
{
    uint32_t bsrr;
    if (on != 0U)
    {
        /* 点亮：按极性输出对应电平 */
        bsrr = (activeHi != 0U) ? (uint32_t)pinMask : ((uint32_t)pinMask << 16);
    }
    else
    {
        /* 熄灭：按极性输出相反电平 */
        bsrr = (activeHi != 0U) ? ((uint32_t)pinMask << 16) : (uint32_t)pinMask;
    }
    port->BSRR = bsrr;
}

static void LED_AllOff(void)
{
    LED_SetLevel(GPIOA, RED_PIN,   LED_ACTIVE_HIGH,   0);
    LED_SetLevel(GPIOB, GREEN_PIN, LED_ACTIVE_HIGH,   0);
    LED_SetLevel(GPIOC, BLUE_PIN,  LED_ACTIVE_HIGH,   0);
#if INCLUDE_BOARD_LED
    LED_SetLevel(GPIOC, BOARD_PIN, BOARD_ACTIVE_HIGH, 0);
#endif
}

#if DIAG_MODE
/* 自检模式：所有 LED 一起快速翻转，方便用万用表逐个测量 */
static void LED_DiagToggle(void)
{
    static uint8_t phase = 0;
    phase ^= 1U;
    LED_SetLevel(GPIOA, RED_PIN,   LED_ACTIVE_HIGH,   phase);
    LED_SetLevel(GPIOB, GREEN_PIN, LED_ACTIVE_HIGH,   phase);
    LED_SetLevel(GPIOC, BLUE_PIN,  LED_ACTIVE_HIGH,   phase);
#if INCLUDE_BOARD_LED
    LED_SetLevel(GPIOC, BOARD_PIN, BOARD_ACTIVE_HIGH, phase);
#endif
}
#endif

/* 配置一个 GPIO 引脚为 2MHz 推挽输出 */
static void LED_ConfigPin(GPIO_TypeDef *port, uint8_t pinIndex)
{
    uint32_t shift;
    __IO uint32_t *cr;
    if (pinIndex < 8U)
    {
        cr = &port->CRL;
        shift = (uint32_t)pinIndex * 4U;
    }
    else
    {
        cr = &port->CRH;
        shift = (uint32_t)(pinIndex - 8U) * 4U;
    }
    /* 每个引脚占4位：[CNF1 CNF0 MODE1 MODE0]
     * 0x2 = 0010b -> CNF=00 通用推挽输出，MODE=10 最大速度2MHz
     */
    *cr = (*cr & ~((uint32_t)0xFU << shift)) | ((uint32_t)0x2U << shift);
}

static void LED_Init(void)
{
    /* 1) 开APB2外设时钟：bit2=GPIOAEN, bit3=GPIOBEN, bit4=GPIOCEN */
    RCC->APB2ENR |= (1UL << 2) | (1UL << 3) | (1UL << 4);
    (void)RCC->APB2ENR;

    /* 2) 先把全部要用的引脚拉成熄灭电平，避免配置瞬间 LED 短暂全亮 */
    LED_AllOff();

    /* 3) PA0 / PB0 配置成推挽输出 (写到 CRL) */
    LED_ConfigPin(GPIOA, 0);
    LED_ConfigPin(GPIOB, 0);

    /* 4) PC13 / PC14 配置成推挽输出 (写到 CRH) */
    LED_ConfigPin(GPIOC, 13);
    LED_ConfigPin(GPIOC, 14);
}

/* SysTick 精确毫秒延时 */
static void LED_DelayMs(uint32_t ms)
{
    while (ms != 0UL)
    {
        SysTick->CTRL = 0UL;
        SysTick->LOAD = (SystemCoreClock / 1000UL) - 1UL;
        SysTick->VAL  = 0UL;
        SysTick->CTRL = 5UL;            /* CLKSOURCE=HCLK, TICKINT=off, ENABLE=on */
        while ((SysTick->CTRL & (1UL << 16)) == 0UL) { /* wait COUNTFLAG */ }
        SysTick->CTRL = 0UL;
        --ms;
    }
}

int main(void)
{
    SystemCoreClockUpdate();
    LED_Init();

#if DIAG_MODE
    /* 自检模式：4个引脚一起以 100ms 频率翻转 */
    while (1)
    {
        LED_DiagToggle();
        LED_DelayMs(100UL);
    }
#else
    while (1)
    {
        /* 第1秒：蓝灯亮 */
        LED_AllOff();
        LED_SetLevel(GPIOC, BLUE_PIN, LED_ACTIVE_HIGH, 1);
        LED_DelayMs(1000UL);

        /* 第2秒：红灯亮 */
        LED_AllOff();
        LED_SetLevel(GPIOA, RED_PIN, LED_ACTIVE_HIGH, 1);
        LED_DelayMs(1000UL);

        /* 第3秒：绿灯亮 */
        LED_AllOff();
        LED_SetLevel(GPIOB, GREEN_PIN, LED_ACTIVE_HIGH, 1);
        LED_DelayMs(1000UL);

#if INCLUDE_BOARD_LED
        /* 第4秒：板载PC13灯亮（完成题目第3项） */
        LED_AllOff();
        LED_SetLevel(GPIOC, BOARD_PIN, BOARD_ACTIVE_HIGH, 1);
        LED_DelayMs(1000UL);
#endif
    }
#endif
}