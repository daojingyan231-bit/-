/*
 * 任务一(1)：串口连续发送实验（HAL库）
 *
 * 题目要求：STM32 给上位机(win10)连续发送 "hello windows!"，
 *           win10 用"串口助手"接收。连续发送之间【不加延时语句】，
 *           观察 win10 端是否出现接收数据丢失的现象。
 *
 * 硬件接线（STM32F103C8T6，USB-TTL 模块与单片机交叉相接、共地）：
 *   PA9  (USART1_TX) -> USB-TTL 的 RX
 *   PA10 (USART1_RX) -> USB-TTL 的 TX（本实验只发不收，仍按标准接法接好）
 *   GND              -> USB-TTL 的 GND
 *
 * 串口参数：115200 波特率，8 数据位，1 停止位，无校验（8-N-1）
 *
 * 【实验现象说明】
 *   本程序主循环中没有任何延时，以最快速度连续发送：
 *   115200bps 下发完14字节约需1.22ms，紧接着又发下一帧。
 *   win10 串口助手（上位机软件）来不及处理/显示如此密集的数据，
 *   会出现接收数据丢失、粘连、错行的现象 —— 即题目要求观察的丢数现象。
 *
 *   本提交保持题目要求的无延时发送条件，不加入人为等待。
 */

#include "stm32f1xx_hal.h"

/* 严格按题目发送"hello windows!"，共14字节，不附加回车换行。 */
static const uint8_t s_tx_msg[] = "hello windows!";
/* 发送内容实际长度（sizeof包含结尾'\0'，故减1；避免手写长度写错） */
#define TX_MSG_LEN       (sizeof(s_tx_msg) - 1U)

/* ---------- 全局句柄 ---------- */
UART_HandleTypeDef huart1;

/* ---------- 函数声明 ---------- */
static void SystemClock_Config(void);
static void MX_USART1_UART_Init(void);
void Error_Handler(void);

/**
  * @brief  UART 底层初始化（HAL_UART_Init 内部自动回调）：
  *         开时钟、配置 PA9/PA10 引脚复用。
  */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef gpio = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();     /* USART1 挂在 APB2 总线(72MHz) */
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* PA9 = USART1_TX：复用推挽输出 */
        gpio.Pin   = GPIO_PIN_9;
        gpio.Mode  = GPIO_MODE_AF_PP;
        gpio.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &gpio);

        /* PA10 = USART1_RX：浮空输入 */
        gpio.Pin   = GPIO_PIN_10;
        gpio.Mode  = GPIO_MODE_INPUT;
        gpio.Pull  = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOA, &gpio);
    }
}

/**
  * @brief  USART1 参数配置：115200-8-N-1，收发模式，无硬件流控。
  */
static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200;                  /* 波特率 115200 */
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;      /* 8位数据 */
    huart1.Init.StopBits     = UART_STOPBITS_1;         /* 1位停止位 */
    huart1.Init.Parity       = UART_PARITY_NONE;        /* 无校验 */
    huart1.Init.Mode         = UART_MODE_TX_RX;         /* 全双工收发 */
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

int main(void)
{
    HAL_Init();                            /* HAL初始化：SysTick 1ms节拍 */
    SystemClock_Config();                  /* 72MHz系统时钟 */
    MX_USART1_UART_Init();                 /* 串口初始化 */

    while (1)
    {
        /* 连续发送，两次发送之间【不加任何延时】（题目要求），
              用于观察 win10 端接收数据丢失现象 */
        HAL_UART_Transmit(&huart1, (uint8_t *)s_tx_msg, TX_MSG_LEN, 100U);
    }
}

/**
  * @brief  系统时钟配置：外部8MHz晶振经PLL 9倍频到72MHz；
  *         HSE失败则回退内部HSI。APB1=36MHz，APB2=72MHz。
  *         USART1挂APB2，72MHz/115200=625，波特率无误差。
  */
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType      = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState            = RCC_HSE_ON;
    osc.HSEPredivValue      = RCC_HSE_PREDIV_DIV1;
    osc.LSEState            = RCC_LSE_OFF;
    osc.LSIState            = RCC_LSI_OFF;
    osc.PLL.PLLState        = RCC_PLL_ON;
    osc.PLL.PLLSource       = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL          = RCC_PLL_MUL9;          /* 8MHz x 9 = 72MHz */
    if (HAL_RCC_OscConfig(&osc) != HAL_OK)
    {
        /* HSE启动失败：回退内部HSI 8MHz */
        osc.OscillatorType  = RCC_OSCILLATORTYPE_HSI;
        osc.HSEState        = RCC_HSE_OFF;
        osc.HSIState        = RCC_HSI_ON;
        osc.PLL.PLLState    = RCC_PLL_OFF;
        if (HAL_RCC_OscConfig(&osc) != HAL_OK)
        {
            Error_Handler();
        }
        clk.SYSCLKSource    = RCC_SYSCLKSOURCE_HSI;
    }
    else
    {
        clk.SYSCLKSource    = RCC_SYSCLKSOURCE_PLLCLK;
    }

    clk.ClockType       = RCC_CLOCKTYPE_HCLK   | RCC_CLOCKTYPE_SYSCLK |
                          RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2;
    clk.AHBCLKDivider   = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider  = RCC_HCLK_DIV2;                 /* APB1最高36MHz */
    clk.APB2CLKDivider  = RCC_HCLK_DIV1;                 /* APB2=72MHz */
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief  错误处理：关闭中断并死循环。
  */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        /* 程序异常时停留在此处，便于调试观察 */
    }
}
