/*
 * 任务一(2)：中断服务函数
 *
 * 轮询方式串口通信不使用任何串口中断，
 * 本文件只保留 SysTick 1毫秒系统节拍（为 HAL_GetTick()/HAL_Delay 提供时基）。
 * 其余异常处理函数使用启动文件中的弱定义默认实现。
 */

#include "stm32f1xx_hal.h"

/**
  * @brief  SysTick 1毫秒节拍中断，供HAL_GetTick()/HAL_Delay()计时使用。
  */
void SysTick_Handler(void)
{
    HAL_IncTick();
}
