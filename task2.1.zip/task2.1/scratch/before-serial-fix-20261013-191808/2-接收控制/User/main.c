/*
 * 任务一(2)：串口接收控制实验（HAL库，轮询方式）
 *
 * 题目要求：在任务一(1)连续发送的基础上继续扩展功能：
 *           当上位机给 STM32 发送一个字符 '#' 后，STM32 暂停发送 "hello windows!"；
 *           发送一个字符 '*' 后，STM32 继续发送。
 *
 * 硬件接线（STM32F103C8T6，USB-TTL 模块与单片机交叉相接、共地）：
 *   PA9  (USART1_TX) -> USB-TTL 的 RX
 *   PA10 (USART1_RX) -> USB-TTL 的 TX
 *   GND              -> USB-TTL 的 GND
 *
 * 串口参数：115200 波特率，8 数据位，1 停止位，无校验（8-N-1）
 *
 * 功能说明：
 *   1. STM32 连续向上位机(Win10)发送 "hello windows!"，
 *      发送间隔由 TX_INTERVAL_MS 控制（默认500ms，便于观察暂停/恢复效果）。
 *   2. 接收采用【轮询方式】：主循环中不断查询 RXNE 标志（接收寄存器非空），
 *      收到字符后判断：
 *        上位机发送 '#' -> 暂停发送；
 *        上位机发送 '*' -> 继续发送。
 *
 * 【任务二(1)提示】轮询方式的局限：HAL_Delay 期间主循环停摆，
 *   RXNE 只能缓冲1个字节，此时发来的 '#'/'*' 可能丢失。
 *   task2.2\1-中断 工程用串口中断方式重做了本实验，可对比两者差异。
 */

#include "stm32f1xx_hal.h"

/* ---------- 运行参数 ---------- */
#define TX_INTERVAL_MS   500U            /* 两次发送之间的间隔，便于观察暂停/恢复 */
#define TX_TIMEOUT_MS    100U            /* 阻塞发送的超时时间 */

/* 发送内容（15字节，不含结尾的'\0'） */
static const uint8_t s_tx_msg[] = "hello windows!\r\n";
/* 发送内容实际长度（sizeof包含结尾'\0'，故减1；避免手写长度写错） */
#define TX_MSG_LEN       (sizeof(s_tx_msg) - 1U)

/* ---------- 全局句柄 ---------- */
UART_HandleTypeDef huart1;

/* ---------- 函数声明 ---------- */
static void SystemClock_Config(void);
static void MX_USART1_UART_Init(void);
void Error_Handler(void);

/**
  * @brief  UART 底层初始化（HAL_UART_Init 内部自动回调）：
  *         开时钟、配置 PA9/PA10 引脚复用。
  */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef gpio = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();     /* USART1 挂在 APB2 总线(72MHz) */
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* PA9 = USART1_TX：复用推挽输出 */
        gpio.Pin   = GPIO_PIN_9;
        gpio.Mode  = GPIO_MODE_AF_PP;
        gpio.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &gpio);

        /* PA10 = USART1_RX：浮空输入 */
        gpio.Pin   = GPIO_PIN_10;
        gpio.Mode  = GPIO_MODE_INPUT;
        gpio.Pull  = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOA, &gpio);
    }
}

/**
  * @brief  USART1 参数配置：115200-8-N-1，收发模式，无硬件流控。
  */
static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200;                  /* 波特率 115200 */
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;      /* 8位数据 */
    huart1.Init.StopBits     = UART_STOPBITS_1;         /* 1位停止位 */
    huart1.Init.Parity       = UART_PARITY_NONE;        /* 无校验 */
    huart1.Init.Mode         = UART_MODE_TX_RX;         /* 全双工收发 */
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

int main(void)
{
    uint8_t tx_enable = 1U;                /* 1=发送中，0=暂停（收到'#'后清零） */
    uint8_t rx_byte;

    HAL_Init();                            /* HAL初始化：SysTick 1ms节拍 */
    SystemClock_Config();                  /* 72MHz系统时钟 */
    MX_USART1_UART_Init();                 /* 串口初始化 */

    while (1)
    {
        /* 1. 轮询接收：查询 RXNE 标志（接收寄存器非空），非阻塞 */
        if (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_RXNE) != RESET)
        {
            /* 读 DR 会自动清除 RXNE 标志 */
            rx_byte = (uint8_t)(huart1.Instance->DR & 0x00FFU);

            if (rx_byte == '#')
            {
                tx_enable = 0U;            /* '#' -> 暂停发送 */
            }
            else if (rx_byte == '*')
            {
                tx_enable = 1U;            /* '*' -> 恢复发送 */
            }
        }

        /* 2. 允许发送时，连续发送 "hello windows!" */
        if (tx_enable != 0U)
        {
            HAL_UART_Transmit(&huart1, (uint8_t *)s_tx_msg, TX_MSG_LEN,
                              TX_TIMEOUT_MS);
        }

        /* 3. 发送间隔（便于观察暂停/恢复的效果；
              改为 0 则与任务一(1)一样满速连续发送） */
        HAL_Delay(TX_INTERVAL_MS);
    }
}

/**
  * @brief  系统时钟配置：外部8MHz晶振经PLL 9倍频到72MHz；
  *         HSE失败则回退内部HSI。APB1=36MHz，APB2=72MHz。
  *         USART1挂APB2，72MHz/115200=625，波特率无误差。
  */
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType      = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState            = RCC_HSE_ON;
    osc.HSEPredivValue      = RCC_HSE_PREDIV_DIV1;
    osc.LSEState            = RCC_LSE_OFF;
    osc.LSIState            = RCC_LSI_OFF;
    osc.PLL.PLLState        = RCC_PLL_ON;
    osc.PLL.PLLSource       = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL          = RCC_PLL_MUL9;          /* 8MHz x 9 = 72MHz */
    if (HAL_RCC_OscConfig(&osc) != HAL_OK)
    {
        /* HSE启动失败：回退内部HSI 8MHz */
        osc.OscillatorType  = RCC_OSCILLATORTYPE_HSI;
        osc.HSEState        = RCC_HSE_OFF;
        osc.HSIState        = RCC_HSI_ON;
        osc.PLL.PLLState    = RCC_PLL_OFF;
        if (HAL_RCC_OscConfig(&osc) != HAL_OK)
        {
            Error_Handler();
        }
        clk.SYSCLKSource    = RCC_SYSCLKSOURCE_HSI;
    }
    else
    {
        clk.SYSCLKSource    = RCC_SYSCLKSOURCE_PLLCLK;
    }

    clk.ClockType       = RCC_CLOCKTYPE_HCLK   | RCC_CLOCKTYPE_SYSCLK |
                          RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2;
    clk.AHBCLKDivider   = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider  = RCC_HCLK_DIV2;                 /* APB1最高36MHz */
    clk.APB2CLKDivider  = RCC_HCLK_DIV1;                 /* APB2=72MHz */
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief  错误处理：关闭中断并死循环。
  */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        /* 程序异常时停留在此处，便于调试观察 */
    }
}
